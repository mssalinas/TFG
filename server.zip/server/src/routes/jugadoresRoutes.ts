import {Router} from 'express';
import { jugadoresController } from '../controllers/jugadoresController';

class JugadoresRoutes {

    public router: Router = Router();

    constructor(){
        this.config();
    }
    config(): void{
        this.router.get('/', jugadoresController.listAll);
        this.router.get('/search', jugadoresController.find);
        this.router.get ('/:id', jugadoresController.getJugador);
        this.router.get ('/equipo/:id', jugadoresController.getJugadoresEquipos);
        this.router.post('/', jugadoresController.create);
        this.router.delete ('/:id', jugadoresController.delete);
        this.router.put('/:id', jugadoresController.update);
    }
}

const jugadoresRoutes = new JugadoresRoutes();
export default jugadoresRoutes.router;