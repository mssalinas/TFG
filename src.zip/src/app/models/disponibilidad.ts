import { Time } from '@angular/common';

export interface Disponibilidad {
  ID?: number;
  usuario?: number;
  fecha_no_disp?: Date;
  desde_hora_no_disp?: string;
  hasta_hora_no_disp?: string;
  motivo: string;
}
