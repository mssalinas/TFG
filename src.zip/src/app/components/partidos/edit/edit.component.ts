import { Component, OnInit, SimpleChanges, OnChanges } from '@angular/core';
import { Partido } from 'src/app/models/partido';
import { Router, ActivatedRoute } from '@angular/router';
import { PartidosService } from 'src/app/services/partidos.service';
import swal from 'sweetalert2';
import { EquiposService } from 'src/app/services/equipos.service';
import { CategoriasService } from 'src/app/services/categorias.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditPartidosComponent implements OnInit {

  equipos: any = [];
  categorias: any = [];
  equiposL: any = [];
  equiposLocales: any = [];
  equiposVisitantes: any = [];
  equiposV: any = [];
  partidos: any = [];

  partido: Partido = {
  equipo_1: 0,
  equipo_2: 0,
  fecha: new Date(),
  categoria: 0,
  };

  edit = true;
  fecha_partido: any;

  textErrorServer: string;
  textoError: string;
  textSearchError: string;
  textEditError: string;
  textEditSuccess: string;
  textSearchSuccess: string;
  textReview: string;

  constructor(private route: Router, private categoriaService: CategoriasService, private equipoService: EquiposService,
              private partidoService: PartidosService, private activeRoute: ActivatedRoute, private translate: TranslateService) { }

  ngOnInit() {
    this.translate.get('partidos.error_partido').subscribe(
      res => {
        this.textoError = res;
      }
    );
    this.translate.get('arbitros.error_server').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    // Parametros de la url
    const params = this.activeRoute.snapshot.params;
    this.equipoService.getEquipos().subscribe(
      res => {
      this.equipos = res;
      }
    );
    this.categoriaService.getCategorias().subscribe(
      res => {
        this.categorias = res;
      }
    );
    if (params.id) {
      this.partidoService.getPartido(params.id)
      .subscribe(
        res => {
          console.log(res);
          // Muestra los datos del usuario en el formulario
          // de edit
          this.partido = res;
          //this.fecha_partido = this.partido.fecha.toString().slice(0,10);
         //console.log(this.partido.fecha.);
        },
        err => {console.error(err);
                swal.fire({
            title: this.textoError,
            text:  this.textErrorServer,
            type: 'error',
            timer: 2500,
          });
        }
      );
        } else {
          this.edit = false;
          this.partidoService.getEquiposLocales().subscribe(
            res => {
                this.equiposL = res;
                this.equiposL.forEach(equipo => {
                  this.equipoService.getDataEquipo(equipo.equipo_1).subscribe(
                    res => {
                     this.equiposLocales.push(res[0]);
                      console.log(this.equiposLocales);
                    }
                  );
                });
            }
          );
          this.partidoService.getEquiposVistantes().subscribe(
            res => {
              this.equiposV = res;
              this.equiposV.forEach(equipo => {
                this.equipoService.getDataEquipo(equipo.equipo_2).subscribe(
                  res => {
                   this.equiposVisitantes.push(res[0]);
                  }
                );
              });
            }
          );
        }
  }

  updatePartido() {
    this.translate.get('partidos_edit.edit_ok').subscribe(
      res => {
        this.textEditSuccess = res;
      }
    );
    this.translate.get('partidos_edit.edit_nook').subscribe(
      res => {
        this.textEditError = res;
      }
    );
    const id = this.activeRoute.snapshot.params.id;
    console.log(this.partido);
    this.partidoService.updatePartido(id, this.partido)
    .subscribe(
        res => {
          this.route.navigate(['/partidos/']);
          swal.fire({
            title: this.textEditSuccess,
            type: 'success',
            timer: 2000,
          });
        },
        err => { console.log(err);
                 swal.fire({
          title: this.textEditError,
          text: this.textReview,
          type: 'error',
          timer: 2500,
        });
      }
    );
  }

  searchPartidos() {
    this.translate.get('partidos_edit.no_results').subscribe(
      res => {
        this.textSearchError = res;
      }
    );
    this.translate.get('partidos.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    this.partidoService.findPartidos(this.partido.fecha, this.partido.hora, this.partido.equipo_1, this.partido.equipo_2,
       this.partido.categoria).subscribe(
      res => {
        this.partidos = res;
        this.route.navigate(['/partidos']);
        this.partidoService.sendData(this.partidos);
    }, err => {
      console.log(err);
      swal.fire({
      title: this.textSearchError,
      text: this.textReview,
      type: 'warning',
      timer: 2500,
      });
    });
  }
}
