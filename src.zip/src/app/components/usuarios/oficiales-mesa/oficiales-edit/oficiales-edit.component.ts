import { Component, OnInit } from '@angular/core';
import { UsuariosService } from '../../../../services/usuarios.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Usuario} from '../../../../models/usuarios';
import swal from 'sweetalert2';
import { CategoriasService } from 'src/app/services/categorias.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-oficiales-edit',
  templateUrl: './oficiales-edit.component.html',
  styleUrls: ['./oficiales-edit.component.css']
})
export class OficialesEditComponent implements OnInit {
  usuarios: any = [];
  categorias: any = [];

  user: Usuario = {
    DNI: '',
    NOMBRE: '',
    APELLIDOS: '',
    PASSWORD: '',
    PERMISO: 3,
    CATEGORIA: 0,
    EMAIL: '',
    TELEFONO: 0,
    FECHA_NACIMIENTO: new Date(),
    IBAN: ''
  };

  edit = true;

  textErrorServer: string;
  textoError: string;
  textSearchError: string;
  textEditError: string;
  textEditSuccess: string;
  textSearchSuccess: string;
  textReview: string;

  constructor(private usuariosService: UsuariosService, private categoriaService: CategoriasService, private route: Router,
              private activeRoute: ActivatedRoute, private translate: TranslateService) { }

  ngOnInit() {
    this.translate.get('oficiales_mesa.error_dat').subscribe(
      res => {
        this.textoError = res;
      }
    );
    this.translate.get('oficiales_mesa.text_error').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    // Parametros de la url
    const params = this.activeRoute.snapshot.params;
    this.categoriaService.getCategorias().subscribe(
      res => {
        this.categorias = res;
        if (params.id) {
      this.usuariosService.getOficial(params.id)
      .subscribe(
        res => {
          console.log(res);
          // Muestra los datos del usuario en el formulario
          // de edit
          this.user = res[0];
         // this.edit = true;
        },
        err => { console.error(err);
                 swal.fire({
                  title: this.textoError,
                  text: this.textErrorServer,
                  type: 'error',
                  timer: 2500,
          });
        }
      );
        } else {
          this.edit = false;
        }
      });
  }

  searchOficiales() {
    this.translate.get('arbitros_edit.no_results').subscribe(
      res => {
        this.textEditError = res;
      }
    );
    this.translate.get('arbitro.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    this.edit = false;
    this.usuariosService.findOficiales(this.user.DNI, this.user.NOMBRE, this.user.APELLIDOS, this.user.CATEGORIA,
       this.user.EMAIL, this.user.TELEFONO, this.user.FECHA_NACIMIENTO, this.user.IBAN).subscribe(
      res => {
        this.usuarios = res;
        this.route.navigate(['/oficiales_mesa']);
        this.usuariosService.sendData(this.usuarios);
    }, err => {
        console.log(err);
        swal.fire({
          title: this.textEditError,
          text: this.textReview,
          type: 'warning',
          timer: 2500,
          });
      }
       );
  }

  updateUser() {
    this.translate.get('arbitros_edit.edit_ok').subscribe(
      res => {
        this.textEditSuccess = res;
      }
    );
    this.translate.get('arbitros_edit.edit_nook').subscribe(
      res => {
        this.textEditError = res;
      }
    );
    this.usuariosService.updateOficial(this.user.ID, this.user)
    .subscribe(
        res => {
          console.log(res);
          swal.fire({
            title: this.textEditSuccess,
            type: 'success',
            timer: 2500,
          });
          this.route.navigate(['/oficiales_mesa/']);
        },
        err => {console.log(err);
                swal.fire({
                  title: this.textEditError,
                  text: this.textReview,
                  type: 'error',
                  timer: 2500,
          });

        }
    );
  };
}
