import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Equipo } from '../models/equipo';

@Injectable({
  providedIn: 'root'
})
export class EquiposService {

  constructor(private http: HttpClient) { }

API_URI = 'http://localhost:3000/api';

getEquipos() {
  return this.http.get(`${this.API_URI}/equipos`);
}
getEquipoClub(id: number) {
  return this.http.get(`${this.API_URI}/equipos/club/${id}`);
}
getDataEquipo(id: number) {
  return this.http.get(`${this.API_URI}/equipos/${id}`);
}
getEquiposCategoria(idcategoria: number, idclub: number) {
  return this.http.get(`${this.API_URI}/equipos/categoria/${idcategoria}?club=${idclub}`);
}
deleteEquipo(id: number) {
  return this.http.delete(`${this.API_URI}/equipos/${id}`);
}
updateEquipo(id: number, equipo: Equipo) {
  return this.http.put(`${this.API_URI}/equipos/${id}`, equipo);
}
saveEquipo(equipo: Equipo) {
  return this.http.post(`${this.API_URI}/equipos`, equipo);
}
}
