import {Router} from 'express';
import {oficialesController} from '../controllers/oficialesController';

class OficilesRoutes{

    public router: Router = Router();

    constructor(){
        this.config();
    }
    config(): void{
         this.router.get ('/', oficialesController.listAll);
         this.router.get('/find', oficialesController.find);
         this.router.get ('/:id', oficialesController.listOneOficial);
         this.router.post ('/', oficialesController.create);
         this.router.delete ('/:id', oficialesController.delete);
         this.router.put('/:id', oficialesController.update);
         this.router.get('/categoria/:id', oficialesController.findOficialesByCategory);
    }
}

const oficialesRoutes = new OficilesRoutes();
export default oficialesRoutes.router;