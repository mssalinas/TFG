import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPartidosComponent } from './edit.component';

describe('EditComponent', () => {
  let component: EditPartidosComponent;
  let fixture: ComponentFixture<EditPartidosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditPartidosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPartidosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
