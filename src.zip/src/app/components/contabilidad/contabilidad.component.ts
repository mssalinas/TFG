import { Component, OnInit, HostBinding, ViewChild, ElementRef } from '@angular/core';
import { NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { PartidosService } from '../../services/partidos.service';
import * as jsPDF from 'jspdf';
import * as html2canvas from 'html2canvas';
import { CategoriasService } from '../../services/categorias.service';
import { UsuariosService } from '../../services/usuarios.service';
import { Partido } from 'src/app/models/partido';
import swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-contabilidad',
  templateUrl: './contabilidad.component.html',
  styleUrls: ['./contabilidad.component.css']
})
export class ContabilidadComponent implements OnInit {

  partidos: any = [];
  partidosem: any = [];
  equipos: any = [];
  categorias: any = [];
  arbitros: any = [];
  usserLogged: string;
  dataUser: any = [];

  userlog: number;
  permisoLog: number;
  importe: number;
  now = new Date();

  closeResult: string;

  partido: Partido = {
    equipo_1: 0,
    equipo_2: 0,
    fecha: new Date(),
    categoria: 0,
    resultado: '',
    arbitro_1: 0,
    arbitro_2: 0,
    arbitro_3: 0
  };

  partido_sem: Partido = {
    equipo_1: 0,
    equipo_2: 0,
    fecha: new Date(),
    categoria: 0,
    resultado: '',
    arbitro_1: 0,
    arbitro_2: 0,
    arbitro_3: 0
  };

  textErrorGet: string;
  textAdmin: string;
  activeLang = 'es';

  public totalImportArbitrosSem = 0;
  public totalImportOficialesSem = 0;
  public totalImportArbitros = 0;
  public totalImportOficiales = 0;


  constructor( private partidoService: PartidosService, private translate: TranslateService, private categoriaService: CategoriasService,
               private usuariosService: UsuariosService) {
                this.translate.setDefaultLang(this.activeLang);
               }
  @HostBinding('class') classes = 'row';
  @ViewChild('alert') alert: ElementRef;
  ngOnInit() {
    this.translate.get('contabilidad.no_par').subscribe(
      res => {
        this.textErrorGet = res;
      }
    );
    this.translate.get('contabilidad_club.admin').subscribe(
      res => {
        this.textAdmin = res;
      }
    );
    this.usserLogged = this.usuariosService.getUserLoggedIn();
    this.usuariosService.getDataUser(this.usserLogged).subscribe(
        res => {
            this.dataUser = res[0];
            this.userlog = res[0].ID;
            this.permisoLog = res[0].PERMISO;
        // Obtiene los partidos de dicho árbitro
            this.partidoService.getmisPartidos(this.userlog).subscribe(
      res => {
        this.partidos = res;
        this.partidos.forEach((partido) => {
         this.partidoService.getDataEquipo(partido.equipo_1).subscribe(
          res => {
            partido.equipo_1 = res[0];
          }
        );
         this.partidoService.getDataEquipo(partido.equipo_2).subscribe(
          res => {
            partido.equipo_2 = res[0];
          });

         this.categoriaService.getDataCategoria(partido.categoria).subscribe(
            res => {
              partido.categoria = res[0];
              this.totalImportArbitros += (res[0].pago_arbitros);
              this.totalImportOficiales += res[0].pago_oficiales;
            }
          );
        });
      },
      err => {
        console.error(err);
     console.log('eee');
        swal.fire({
        title: this.textErrorGet,
        text: this.textAdmin,
        type: 'warning',
        timer: 2000,
      });
      }
    );
            this.partidoService.getmisPartidosSemana(this.userlog).subscribe(
      res => {
        this.partidosem = res;
        this.partidosem.forEach((partido_sem) => {
          this.partidoService.getDataEquipo(partido_sem.equipo_1).subscribe(
          res => {
            partido_sem.equipo_1 = res[0];
          }
        );
          this.partidoService.getDataEquipo(partido_sem.equipo_2).subscribe(
          res => {
            partido_sem.equipo_2 = res[0];
          });

          this.categoriaService.getDataCategoria(partido_sem.categoria).subscribe(
            res => {
              partido_sem.categoria = res[0];
              this.totalImportArbitrosSem += (res[0].pago_arbitros);
              this.totalImportOficialesSem += res[0].pago_oficiales;
            }
          );
        });
      },
      err => {console.error(err);
              swal.fire({
              title: this.textErrorGet,
              text: this.textAdmin,
              type: 'warning',
              timer: 3000,
            });
          }
    );


  });
  }
  download() {
    document.getElementById("templatepdf").style.display = "block";
    const data = document.getElementById('templatepdf');
    html2canvas(data).then(canvas => {
    // Few necessary setting options
    const imgWidth = 208;
    const pageHeight = 295;
    const imgHeight = canvas.height * imgWidth / canvas.width;
    const heightLeft = imgHeight;
    const contentDataURL = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4'); // A4 size page of PDF
    const position = 0;
    pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight);
    pdf.save('resumenCont' + this.userlog + '.pdf'); // Generated PDF
    document.getElementById("templatepdf").style.display = "none";
  });
}

}

