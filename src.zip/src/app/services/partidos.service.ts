import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Partido } from '../models/partido';
import { Time } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class PartidosService {
  constructor(private http: HttpClient) {}

  API_URI = 'http://localhost:3000/api';
  public arrayPartidos;

  getPartidos() {
    return this.http.get(`${this.API_URI}/partidos`);
  }
  getPartido(id: number) {
    return this.http.get(`${this.API_URI}/partidos/${id}`);
  }
  deletePartido(id: number) {
    return this.http.delete(`${this.API_URI}/partidos/${id}`);
  }
  savePartido(partido: Partido) {
    return this.http.post(`${this.API_URI}/partidos`, partido);
  }
  updatePartido(id: number, partido: Partido) {
    return this.http.put(`${this.API_URI}/partidos/${id}`, partido, {
      reportProgress: true,
      observe: 'events'
    });
  }
  getDataEquipo(id: number) {
    return this.http.get(`${this.API_URI}/equipos/${id}`);
  }
  getDataArbitrosCategoria(id: number, idpartido: number) {
    return this.http.get(
      `${this.API_URI}/arbitros/categoria/${id}?partido=${idpartido}`
    );
  }
  getDataOficialesCategoria(id: number, idpartido: number) {
    return this.http.get(
      `${this.API_URI}/oficiales_mesa/categoria/${id}?partido=${idpartido}`
    );
  }
  getmisPartidos(id: number) {
    return this.http.get(`${this.API_URI}/partidos/misPartidos/${id}`);
  }
  getmisPartidosSemana(id: number) {
    return this.http.get(`${this.API_URI}/partidos/misPartidos/semana/${id}`);
  }
  getPartidosClub(id: number) {
    return this.http.get(`${this.API_URI}/partidos/club/${id}`);
  }
  getPartidosEquipo(id: number) {
    return this.http.get(`${this.API_URI}/partidos/equipo/${id}`);
  }
  getPartidosContaMes(id: number) {
    return this.http.get(`${this.API_URI}/partidos/contabilidadM/${id}`);
  }
  getPartidosContaAno(id: number) {
    return this.http.get(`${this.API_URI}/partidos/contabilidadA/${id}`);
  }
  getEquiposLocales() {
    return this.http.get(`${this.API_URI}/partidos/equipol/`);
  }
  getEquiposVistantes() {
    return this.http.get(`${this.API_URI}/partidos/equipov/`);
  }
  findPartidos(
    fecha: Date,
    hora: Time,
    equipo_1: number,
    equipo_2: number,
    categoria: number
  ) {
    return this.http.get(
      `${
        this.API_URI
      }/partidos/find/?fecha=${fecha}&hora=${hora}&equipo_1=${equipo_1}&equipo_2=${equipo_2}&categoria=${categoria}`
    );
  }
  sendData(array: any) {
    this.arrayPartidos = array;
  }
  getData() {
    return this.arrayPartidos;
  }
  removeData() {
    this.arrayPartidos = [];
  }
}
