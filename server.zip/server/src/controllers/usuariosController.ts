import { Request, Response } from "express";

import db from "../database";

class UsuariosController {
  public async listAll(req: Request, res: Response) {
    const arbitros = await db.query("SELECT * from usuarios");
    res.json(arbitros);
  }
  public async listOne(req: Request, res: Response): Promise<any> {
    const { id } = req.params;
    const arbitro = await db.query("SELECT * from usuarios where id= ? ", [id]);
    if (arbitro.length > 0) {
      return res.json(arbitro[0]);
    }
    res.status(404).json({ text: "Usuario no encontrado" });
  }
  public async getOficiales(req: Request, res: Response) {
    const oficiales = await db.query(
      "SELECT * from usuarios WHERE PERMISO = 3"
    );
    if (oficiales.length > 0) {
      return res.json(oficiales[0]);
    }
    res.status(404).json({ text: "Usuario no encontrado" });
  }
  public async create(req: Request, res: Response): Promise<void> {
    await db.query("INSERT INTO usuarios set ?", [req.body]);
    res.json({ message: "Arbitros creado" });
  }
  public async delete(req: Request, res: Response) {
    const { id } = req.params;
    await db.query("DELETE from usuarios where id= ?", [id]);
    res.json({ message: "Usuario eliminado correctamente" });
  }
  public async update(req: Request, res: Response) {
    const { id } = req.params;
    await db.query("UPDATE usuarios set ? WHERE id = ?", [req.body, id]);
    res.json({ message: "User was update" });
  }
  public async findUserByEmail(req: Request, res: Response) {
    const user = await db.query("SELECT * FROM usuarios WHERE EMAIL = ?", [
      req.params.email
    ]);
    if (user.length > 0) {
      return res.json(user);
    } else {
      const club = await db.query("SELECT * FROM clubes WHERE email = ?", [req.params.email]);
      if (club.length > 0 ){
        return res.json(club);
      }
    }
    res.status(404).json({ text: "Usuario no encontrado" });
  }
  public async findUserByEmailCategory(req: Request, res: Response) {
    const user = await db.query(
      "SELECT categoria FROM usuarios WHERE EMAIL = ?",
      [req.params.email]
    );
    if (user.length > 0) {
      return res.json(user);
    }
    res.status(404).json({ text: "Usuario no encontrado" });
  }
}

export const usuariosController = new UsuariosController();
