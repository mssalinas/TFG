import {Router} from 'express';
import { arbitrosController} from '../controllers/arbitrosController';

class ArbitrosRoutes{

    public router: Router = Router();

    constructor(){
        this.config();
    }
    config(): void {
        this.router.get('/', arbitrosController.listAll);
        this.router.get('/find', arbitrosController.find);
        this.router.get ('/:id', arbitrosController.listOneArbitro);
        this.router.post ('/', arbitrosController.create);
        this.router.delete ('/:id', arbitrosController.delete);
        this.router.put('/:id', arbitrosController.update);
        this.router.get('/categoria/:id', arbitrosController.findArbitroByCategory);
        //this.router.get('/search', arbitrosController.listAll);
    }
}

const arbitrosRoutes = new ArbitrosRoutes();
export default arbitrosRoutes.router;