import { Request, Response} from 'express';

import db from '../database';

class DisponibilidadController  {

    public async listAll (req: Request,res: Response) {
        const disp = await db.query('SELECT * from disponibilidad');
         res.json(disp);
     }  
    public async insert (req: Request,res: Response): Promise<void>{
        await db.query('INSERT INTO disponibilidad set ?', [req.body]) 
         res.json({message: 'Guardada la disponibilidad'});
     }

    public async getNoDisp (req: Request, res: Response){
       const nodisp = await db.query('SELECT * from disponibilidad where usuario = ? ORDER BY fecha_no_disp', [req.params.id]);
       if (nodisp.length > 0){
           res.json(nodisp);
       }
       res.status(404).json({text: 'No hay datos de no disponibilidad'});
    }
     public async delete (req: Request,res: Response){
         const {id} = req.params;
        const disp =  await db.query('DELETE FROM disponibilidad WHERE id = ?', [id]);
         if(disp.length > 0){
         res.status(200);
         }
     }
     /*
     public async  update (req: Request,res: Response){
        const {id} = req.params;
        await db.query('UPDATE usuarios set ? WHERE id = ?', [req.body, id]);
        res.json({message:'Árbitro actualizado correctamente'});
     }
     public async find (req:Request, res:Response){
         //TO-DO
     }
   */
}
export const disponibilidadController  = new DisponibilidadController();