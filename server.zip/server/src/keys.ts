export default{
    database: {
        host: 'localhost',
        user: 'root',
        database: 'mycommitte'

    }
}