import { Component, OnInit, OnChanges, Compiler } from '@angular/core';
import { AuthenticationService } from '../../services/authentication.service';
import { UsuariosService } from '../../services/usuarios.service';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-cabecera',
  templateUrl: './cabecera.component.html',
  styleUrls: ['./cabecera.component.css']
})
export class CabeceraComponent {
  usserLogged: string;
  userlog: any;
  log: any;
  dataUser: any;
  public activeLang = 'es';

  constructor(private auth: AuthenticationService, private user: UsuariosService, private router: Router,
              private translate: TranslateService, private compiler: Compiler) {
                this.translate.setDefaultLang(this.activeLang);
              }

    ngOnInit() {
      this.usserLogged = this.user.getUserLoggedIn();
      this.user.getDataUser(this.usserLogged).subscribe(
        res => {
          this.dataUser = res[0];
          if (res[0].PERMISO == null) {
            this.userlog = 4;
          } else {
          this.userlog = res[0].PERMISO;
          }
        });
    }
    ngDoCheck() {
      this.log = this.auth.isAuthenticated();
    }

    logout() {
      this.auth.logout();
      console.log(this.userlog);
      this.router.navigate(['/login']);
      this.userlog = 0;
          }

          cambiarLenguaje(lang) {
            this.activeLang = lang;
            this.translate.use(lang);
          }
}
