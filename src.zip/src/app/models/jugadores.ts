export interface Jugadores {
  id?: number;
  club?: number;
  equipo?: number;
  DNI?: string;
  nombre?: string;
  apellidos?: string;
  fecha_nacimiento?: string;
  dorsal_juego?: number;
}
