import { Request, Response } from "express";

import db from "../database";
import { isNull } from "util";

class PartidosController {
  public async listAll(req: Request, res: Response) {
    const partidos = await db.query("SELECT * from partidos");
    res.json(partidos);
  }
  public async getPartido(req: Request, res: Response): Promise<any> {
    const { id } = req.params;
    const partido = await db.query("SELECT * from partidos where id= ? ", [id]);
    if (partido.length > 0) {
      return res.json(partido[0]);
    }
    res.status(404).json({ text: "Partido no encontrado" });
  }
  public async create(req: Request, res: Response): Promise<void> {
    console.log(req.body);
    await db.query('INSERT INTO partidos set ?', [req.body]);
    res.json({ message: "Partido creado correctamente" });
  }
  public async delete(req: Request, res: Response) {
    const { id } = req.params;
    await db.query("DELETE from partidos where id= ?", [id]);
    res.json({ message: "Partido eliminado correctamente" });
  }
  public async update(req: Request, res: Response) {
    const { id } = req.params;
    const partido = await db.query("SELECT * from partidos WHERE id = ?", [id]);
    if (partido.length > 0) {
      await db.query("UPDATE partidos set ? WHERE id = ?", [req.body, id]);
      res.json({ message: "Partido actualizado correctamente" });
    } else {
      res.json({ message: "El partido no existe en la base de datos" });
    }
  }
  public async getPartidosArbitrosOficiales(req: Request, res: Response) {
    const { id } = req.params;
    const partidos = await db.query(
      'SELECT * FROM partidos WHERE arbitro_1 = ? or arbitro_2 = ? or arbitro_3 = ? or oficial_1 = ? or oficial_2 = ? or oficial_3 = ? order by fecha',
      [id, id, id, id, id, id]
    );
    if (partidos.length > 0) {
      return res.json(partidos);
    }
    res.status(404).json({ text: "No tiene ningún partido designado" });
  }
  public async getPartidosSemanaArbitrosOficiales(req: Request, res: Response) {
    const { id } = req.params;
    const partidos = await db.query(
      "SELECT * FROM partidos WHERE fecha >= CURRENT_DATE and ( arbitro_1 = ? or arbitro_2 = ? or arbitro_3 = ? or oficial_1 = ? or oficial_2 = ? or oficial_3 = ?) order by fecha",
      [id, id, id, id, id, id]
    );
    if (partidos.length > 0) {
      return res.json(partidos);
    }
    res.status(404).json({ text: "No tiene ningún partido designado" });
  }
  public async find(req: Request, res: Response) {
    console.log(req.query);
    const partido = await db.query('SELECT * FROM partidos WHERE fecha = ? or hora = ? or equipo_1 = ? or equipo_2 = ? or categoria = ? ', 
    [req.query.fecha, req.query.hora, req.query.equipo_1, req.query.equipo_2, req.query.categoria]);
    if (partido.length > 0){
      res.json(partido);
    }else{
      console.log('not found')
      res.status(404).json({text: "No se han encontrado resultados de búsqueda"});
    }
  }
  public async getPartidosSemana (req: Request, res: Response){
    const partidos = await db.query('SELECT * FROM partidos WHERE fecha >= CURRENT_DATE ORDER BY fecha');
    if (partidos.length > 0) {
      return res.json(partidos);
    }
    res.status(404).json({ text: "No se disputan partidos esta semana" })
  }

  public async getPartidosClub (req: Request, res: Response){
    let array : any = [];
    const equipos = await db.query('SELECT * from equipos WHERE club = ?', [req.params.id]);
    if (equipos.length > 0) {
      for (let i in equipos) {
        let equipo = equipos[i].id;
        const partidos = await db.query(
          'SELECT * FROM partidos WHERE equipo_1 = ? or equipo_2 = ? ORDER BY FECHA ',
          [equipo, equipo]
        );
        if (partidos.length > 0) {
         array.push(partidos);
      }
      }     
            return res.json(array);
    } else {
        res.status(404).json({text: "No se han encontrado equipos"});
    }
  }
  public async getPartidosEquipos (req: Request, res: Response) {
    const { id } = req.params
    console.log(id);
    const partidos = await db.query('SELECT * from partidos WHERE equipo_1 = ? or equipo_2 = ? ORDER BY FECHA', [id, id]);
     if (partidos.length > 0){
        res.json(partidos);
     } else{
     res.status(404).json({text: "No se han encontrado partidos para el equipo"});
     }
  }

  public async getPartidosClubMes (req: Request, res: Response){
    let array : any = [];
    const equipos = await db.query('SELECT * from equipos WHERE club = ?', [req.params.id]);
    if (equipos.length > 0) {
      for (let i in equipos) {
        let equipo = equipos[i].id;
        const partidos = await db.query(
          'SELECT * FROM partidos WHERE (equipo_1 = ? or equipo_2 = ?) and MONTH(fecha) = MONTH(CURRENT_DATE()) ORDER BY FECHA ',
          [equipo, equipo]
        );
        console.log(partidos);
        if (partidos.length > 0) {
          array.push(partidos);
        } else {
        //res.status(404).json({text:"Los equipos no disputan ningún partido"});
      }
      }
          return res.json(array);
    } else {
        res.status(404).json({text: "No se han encontrado equipos"});
    }
  }
  public async getPartidosClubAnual (req: Request, res: Response){
    let array : any = [];
    const equipos = await db.query('SELECT * from equipos WHERE club = ?', [req.params.id]);
    if (equipos.length > 0) {
      for (let i in equipos) {
        let equipo = equipos[i].id;
        const partidos = await db.query(
          'SELECT * FROM partidos WHERE (equipo_1 =? or equipo_2 = ?) and YEAR(fecha) = YEAR(CURDATE()) ORDER BY FECHA',
          [equipo, equipo]
        );
        if (partidos.length > 0) {
          array.push(partidos);
        } else {
        //res.status(404).json({text:"Los equipos no disputan ningún partido"});
      }
      }
          return res.json(array);
    } else {
        res.status(404).json({text: "No se han encontrado equipos"});
    }
  }
  public async getEquiposLocales (req: Request, res: Response){
    const equipos_l = await db.query('SELECT equipo_1 from partidos');
    res.json(equipos_l);
  }
  public async getEquiposVisitantes (req: Request, res: Response){
    const equipos_v = await db.query('SELECT equipo_2 from partidos');
    res.json(equipos_v);
  }
}
export const partidosController = new PartidosController();
