import { Component, OnInit } from '@angular/core';
import { EmailService } from 'src/app/services/email.service';
import swal from 'sweetalert2';
import { Email } from 'src/app/models/email';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-email',
  templateUrl: './email.component.html',
  styleUrls: ['./email.component.css']
})
export class EmailComponent {
  email: Email = {
    to: '',
    subject: '',
    message: ''
  };
  activeLang = 'es';
  textOK: string;
  textKO: string;
  textRevisa: string;

  constructor(public emailService: EmailService, private translate: TranslateService) {
    this.translate.setDefaultLang(this.activeLang);
  }
   contactForm() {
    this.translate.get('email.email_ok').subscribe(
      res => {
        this.textOK = res;
      }
    );
    this.translate.get('email.email_ko').subscribe(
      res => {
        this.textKO = res;
      }
    );
    this.translate.get('partidos.revisa').subscribe(
      res => {
        this.textRevisa = res;
      }
    );
    this.emailService.sendEmail(this.email).subscribe( res => {
     swal.fire({
      title: this.textOK,
      type: 'success',
      timer: 2000,
    });
   }, err => {
    swal.fire({
      title: this.textKO,
      text: this.textRevisa,
      type: 'warning',
      timer: 2000,
    });
   });
   }
}
