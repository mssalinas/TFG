import { Component, OnInit, HostBinding } from '@angular/core';
import { UsuariosService } from '../../../services/usuarios.service';
import { CategoriasService } from '../../../services/categorias.service';
import { Usuario } from '../../../models/usuarios';
import { Router, ActivatedRoute } from '@angular/router';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import swal from 'sweetalert2';
import { isNullOrUndefined } from 'util';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-oficiales-mesa',
  templateUrl: './oficiales-mesa.component.html',
  styleUrls: ['./oficiales-mesa.component.css']
})
export class OficialesMesaComponent implements OnInit {
  usuarios: any = [];
  usuariosAux: any = [];
  closeResult: string;
  categorias: any = [];

  user: Usuario = {
    DNI: '',
    NOMBRE: '',
    APELLIDOS: '',
    PASSWORD: '',
    PERMISO: 3,
    CATEGORIA: 0,
    EMAIL: '',
    TELEFONO: 0,
    FECHA_NACIMIENTO: new Date(),
    IBAN: ''
  };
  addForm: FormGroup;

  activeLang = 'es';
  textAddSuccess: string;
  textAddError: string;
  textErrorServer: string;
  texError: string;
  textReview: string;
  textSuccessDelete: string;
  textErrorDetele: string;

  constructor( private usuarioService: UsuariosService,  private route: Router, private modalService: NgbModal,
               private categoriaService: CategoriasService, private form: FormBuilder,  private translate: TranslateService) {
                this.addForm = this.form.group({
                  DNI: ['', [Validators.required, Validators.maxLength(9), Validators.minLength(9),
                    Validators.pattern('^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKE]$')]],
                  password: ['', [Validators.required]],
                  nombre: ['', [Validators.required]],
                  apellidos: ['', [Validators.required]],
                  fecha_nacimiento: ['', [Validators.required]],
                  email: ['', [Validators.required, Validators.email, Validators.minLength(7)]],
                  categoria: ['', [Validators.required]],
                  telefono: ['', [Validators.required]],
                  IBAN: ['', [Validators.required,
                    Validators.pattern('^([A-Z]{2}[ \-]?[0-9]{2})(?=(?:[ \-]?[A-Z0-9]){9,30}$)((?:[ \-]?[A-Z0-9]{3,5}){2,7})([ \-]?[A-Z0-9]{1,3})?$')]],
                });
                this.translate.setDefaultLang(this.activeLang);

               }

  @HostBinding('class') classes = 'row';
  ngOnInit() {
    this.translate.get('oficiales_mesa.error_dat').subscribe(
      res => {
        this.texError = res;
      }
    );
    this.translate.get('oficiales_mesa.text_error').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    this.usuariosAux = this.usuarioService.getData();
    const value = isNullOrUndefined(this.usuariosAux);
    if (value || this.usuariosAux.length === 0) {
      this.getUserRefresh();
    } else {
      this.usuarios = this.usuarioService.getData();
      this.usuarioService.removeData();
    }
  }

  getUserRefresh() {
    this.categoriaService.getCategorias().subscribe(
      res => {
        this.categorias = res;
      }
    );
    this.usuarioService.getOficiales().subscribe(
      res => {
        this.usuarios = res;
        this.usuarios.forEach((user) => {
          this.categoriaService.getDataCategoria(user.CATEGORIA).subscribe(
            resp => {
             user.CATEGORIA = resp[0];
            }
          );
        });
      },
      err => {console.error(err);
              swal.fire({
                title: this.texError,
                text:  this.textErrorServer,
                type: 'error',
                timer: 2500,
        });
      }
    );
  }
  deleteOficial(ID: number) {
    this.translate.get('oficiales_mesa.sucess_delete').subscribe(
      res => {
        this.textSuccessDelete = res;
      }
    );
    this.translate.get('oficiales_mesa.error_delete').subscribe(
      res => {
        this.textErrorDetele = res;
      }
    );
    this.usuarioService.deleteUsuario(ID).subscribe(
      res => {
        this.getUserRefresh();
        swal.fire({
          title: this.textSuccessDelete,
          type: 'success',
          timer: 2000,
        });
      },
      err => {console.log(err);
              swal.fire({
                title: this.textErrorDetele,
                text: this.textErrorServer,
                type: 'error',
                timer: 2500,
        });
      }
    );
  }
  saveUser() {
    this.translate.get('oficiales_mesa.success_add').subscribe(
      res => {
        this.textAddSuccess = res;
      }
    );
    this.translate.get('oficiales_mesa.error_add').subscribe(
      res => {
        this.textAddError = res;
      }
    );
    this.translate.get('oficiales_mesa.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    this.usuarioService.saveUsuario(this.user)
    .subscribe(
      res => {
        console.log(this.user);
        console.log(res);
        this.route.navigate(['/oficiales_mesa']);
      },
      err => {console.log(err);
              swal.fire({
          title: this.textAddSuccess,
          type: 'success',
          timer: 2000,
        });
      }
    );
  }

   // -----CÓDIGO PARA MODAL ----

   open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }


}
