import {Router} from 'express';
import { partidosController } from '../controllers/partidosController';

class PartidoRoutes{

    public router: Router = Router();

    constructor(){
        this.config();
    }
    config(): void{
        
        this.router.get('/', partidosController.getPartidosSemana);
        this.router.get('/equipol', partidosController.getEquiposLocales);
        this.router.get('/equipov', partidosController.getEquiposVisitantes);
        this.router.get('/find', partidosController.find);
        this.router.get ('/:id', partidosController.getPartido);
        this.router.post ('/', partidosController.create);
        this.router.delete ('/:id', partidosController.delete);
        this.router.put('/:id', partidosController.update);
        this.router.get('/misPartidos/:id', partidosController.getPartidosArbitrosOficiales);
        this.router.get('/misPartidos/semana/:id', partidosController.getPartidosSemanaArbitrosOficiales);
        this.router.get('/club/:id', partidosController.getPartidosClub);
        this.router.get('/equipo/:id', partidosController.getPartidosEquipos);
        this.router.get('/contabilidadM/:id', partidosController.getPartidosClubMes);
        this.router.get('/contabilidadA/:id', partidosController.getPartidosClubAnual);
       
    }
}

const partidosRoutes = new PartidoRoutes();
export default partidosRoutes.router;