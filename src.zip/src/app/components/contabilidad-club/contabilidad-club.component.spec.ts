import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContabilidadClubComponent } from './contabilidad-club.component';

describe('ContabilidadClubComponent', () => {
  let component: ContabilidadClubComponent;
  let fixture: ComponentFixture<ContabilidadClubComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContabilidadClubComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContabilidadClubComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
