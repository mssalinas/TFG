import { Component, HostBinding, ViewChild, ElementRef } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { DisponibilidadService } from '../../services/disponibilidad.service';
import { UsuariosService } from '../../services/usuarios.service';
import { Disponibilidad } from '../../models/disponibilidad';
import { Router } from '@angular/router';
import swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-disponibilidad',
  templateUrl: './disponibilidad.component.html',
  styleUrls: ['./disponibilidad.component.css']
})
export class DisponibilidadComponent  {
  closeResult: string;

  usserLogged: string;
  dataUser: any = [];

  activeLang = 'es';
  textOK: string;
  textKO: string;
  textReview: string;
  textConsulta: string;

  disponibilidad: Disponibilidad = {
    usuario: this.dataUser,
    fecha_no_disp: new Date(),
    desde_hora_no_disp: new Date().toTimeString().split(' ')[0],
    hasta_hora_no_disp: new Date().toTimeString().split(' ')[0],
    motivo: ''
  };
  constructor(private route: Router, private modalService: NgbModal, private userService: UsuariosService,
              private dispService: DisponibilidadService, private translate: TranslateService) {
                this.translate.setDefaultLang(this.activeLang);
              }

@ViewChild('alert') alert: ElementRef;

  saveDisp() {
    this.translate.get('disponibilidad.info_ok').subscribe(
      res => {
        this.textOK = res;
      }
    );
    this.translate.get('disponibilidad.consulta').subscribe(
      res => {
        this.textConsulta = res;
      }
    );
    this.translate.get('disponibilidad.info_ko').subscribe(
      res => {
        this.textKO = res;
      }
    );
    this.translate.get('club.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    this.usserLogged = this.userService.getUserLoggedIn();
    this.userService.getDataUser(this.usserLogged).subscribe(
      res => {
          this.dataUser = res[0].ID;
          this.disponibilidad.usuario = this.dataUser;
          this.dispService.saveDisp(this.disponibilidad).subscribe(
               res => {
                 console.log(res);
                 swal.fire({
                  title: this.textOK,
                  text: this.textConsulta,
                  type: 'success',
                  timer: 2000,
                });
                 this.route.navigate(['/disponibilidad']);
      },
      err => {
        console.log(err);
       // swal('¡Se ha porducido un error al guardar tú disponibilidad!', 'Revisa los datos', 'error');
        swal.fire({
        title: this.textKO,
        text: this.textReview,
        type: 'error',
        timer: 2000,
      });
      }
    );
      });
  }

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

}
