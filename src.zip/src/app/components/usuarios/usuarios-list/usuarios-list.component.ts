import { Component, OnInit, HostBinding } from '@angular/core';
import { UsuariosService } from '../../../services/usuarios.service';
import { Router, ActivatedRoute } from '@angular/router';
import swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-usuarios-list',
  templateUrl: './usuarios-list.component.html',
  styleUrls: ['./usuarios-list.component.css']
})
export class UsuariosListComponent implements OnInit {
  @HostBinding('class') class = 'row';

  usuarios: any = [];
  usserLogged: any;
  permiso: number;
  public activeLang = 'es';
  constructor(private usuariosService: UsuariosService, private translate: TranslateService) {
    this.translate.setDefaultLang(this.activeLang);
   }

  ngOnInit() {
    this.getUserRefresh();
  }

  getUserRefresh() {
    this.usuariosService.getUsuarios().subscribe(
      res => {
        this.usuarios = res;
      },
      err => {
        console.error(err);
        swal.fire({
          title: '¡Se ha porducido un error al obtener los usuarios!',
          text: 'Revisa la conexión con el servidor',
          type: 'error',
          timer: 2500,
        });
      }
    );
  }

  /*ngOnInit() {
    const params = this.activeRoute.snapshot.params;
    if (params.id) {
      this.usuariosService.getUsuarios()
      .subscribe(
        res => {
          console.log(res);
          // Muestra los datos del usuario en el formulario
          // de edit
          this.user = res;
          this.edit = true;
        },
        err => console.error(err)
      );
        }
  }

  saveUser() {
    this.usuariosService.saveUsuario(this.user)
    // console.log(this.user);
    .subscribe(
      res => {
        console.log(res);
        this.route.navigate(['/usuarios']);
      },
      err => console.log(err)
    );
  }

  updateUser() {
    //Si no quiero que modifique un dato delete this.user.dato
    this.usuariosService.updateUsuario(this.user.ID, this.user)
    .subscribe(
        res => {
          console.log(res);
          this.route.navigate(['/usuarios']);
        },
        err => console.log(err)
    );

    }*/
}
