export interface Response {
  dataUser: {
    ID?: number;
    DNI?: string;
    PASSWORD?: string;
    NOMBRE?: string;
    APELLIDOS?: string;
    PERMISO?: number;
    CATEGORIA?: string;
    EMAIL?: string;
    TELEFONO?: number;
    FECHA_NACIMIENTO?: Date;
    IBAN?: string;
    accessToken: string;
    expiresIn: string;

  };

}
