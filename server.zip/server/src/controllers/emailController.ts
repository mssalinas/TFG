import * as nodemailer from 'nodemailer';

class Mail {

    constructor(
        public to?: string,
        public subject?: string,
        public message?: string) { }


    sendMail(): any {

        let mailOptions = {
            from: "mssalinas@esei.uvigo.es",
            to: this.to,
            subject: this.subject,
            html: this.message
        };

        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
            user: 'aeromilly@gmail.com', // Cambialo por tu email
            pass: 'Asterisco311' // Cambialo por tu password
            }
            });


        console.log(mailOptions);

        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
                return 'error';
            } else {
                console.log('eee');
                return 'E-mail enviado com exito!';
            }
        });
        
    }

}
export default new Mail;
//export const emailController  = new EmailController();