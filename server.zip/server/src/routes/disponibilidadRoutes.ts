import {Router} from 'express';
import { disponibilidadController } from '../controllers/disponibilidadController';

class DisponibilidadRoutes {

    public router: Router = Router();

    constructor(){
        this.config();
    }
    config(): void{
        this.router.get('/', disponibilidadController.listAll);
        this.router.get ('/:id', disponibilidadController.getNoDisp);
        this.router.post ('/', disponibilidadController.insert);
        this.router.delete ('/:id', disponibilidadController.delete);
        //this.router.put('/:id', arbitrosController.update);
        //this.router.get('/categoria/:id', arbitrosController.findArbitroByCategory);
    }
}

const dispobilidadRoutes = new DisponibilidadRoutes();
export default dispobilidadRoutes.router;