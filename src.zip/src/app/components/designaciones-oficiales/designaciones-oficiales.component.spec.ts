import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DesignacionesOficialesComponent } from './designaciones-oficiales.component';

describe('DesignacionesOficialesComponent', () => {
  let component: DesignacionesOficialesComponent;
  let fixture: ComponentFixture<DesignacionesOficialesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DesignacionesOficialesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesignacionesOficialesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
