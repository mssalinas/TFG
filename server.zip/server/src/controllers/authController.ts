import { Request, Response } from "express";
const jwt = require("jsonwebtoken");

import db from "../database";

class AuthController {

  public async login(req: Request, res: Response) {
    var email = req.body.email;
    var password = req.body.password;
    const log = await db.query('SELECT * FROM usuarios WHERE email = ?', [
      email
    ]);
    if (log.length != 0) {
      if (log[0].PASSWORD == password) {
        var access_token = jwt.sign(
          { email: req.body.email },
          "todo-secret-app",
          { expiresIn: "2h" }
        );
        res.json({ access_token });
      } else {
        res.status(401).json({text: 'Credenciales de acceso no válidas'})
      }
    } else {
      const equipo = await db.query('SELECT * from clubes where email= ? ', [email]);
      console.log(equipo);
      if (equipo.length != 0) {
        if (equipo[0].password == password) {
          var access_token = jwt.sign(
            { email: req.body.email },
            "todo-secret-app",
            { expiresIn: "2h" }
          );
          res.json({ access_token });
        } else {
          res.status(401).json({text: 'Credenciales de acceso no válidas'})
        }
      }
     }
  }
}
export const authController = new AuthController();
