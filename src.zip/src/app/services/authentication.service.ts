import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  API_URI = 'http://localhost:3000/api';

  token: string;

  constructor(private httpClient: HttpClient, private router: Router) { }

    login(email: string, password: string) {
    return this.httpClient.post<{access_token: string}>(`${this.API_URI}/login`, {email, password}).pipe(tap(res => {
    localStorage.setItem('access_token', res.access_token);
    localStorage.setItem('currentUser', email);
      }));
       }

      isAuthenticated(): boolean {
        return (localStorage.getItem('access_token') != null) ? true : false;
      }

    logout() {
      localStorage.removeItem('access_token');
      localStorage.reload(true);
    }


}
