import { Component, OnInit } from '@angular/core';
import { Equipo } from 'src/app/models/equipo';
import { EquiposService } from 'src/app/services/equipos.service';
import swal from 'sweetalert2';
import { Router, ActivatedRoute } from '@angular/router';
import { CategoriasService } from 'src/app/services/categorias.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-edit-equipo',
  templateUrl: './edit-equipo.component.html',
  styleUrls: ['./edit-equipo.component.css']
})
export class EditEquipoComponent implements OnInit {

  equipo: Equipo  = {
    id: 0,
    club: 0,
    nombre: '',
    categoria: 0,
    num_jugadores: 0
  };
  categorias: any = [];

  textErrorServer: string;
  textoError: string;
  textEditError: string;
  textEditSuccess: string;
  textReview: string;

  constructor(private equipoService: EquiposService, private categoriaService: CategoriasService, private activeRoute: ActivatedRoute,
              private router: Router, private translate: TranslateService) { }
  ngOnInit() {
    this.translate.get('equipos_edit.get_error').subscribe(
      res => {
        this.textoError = res;
      }
    );
    this.translate.get('club.conexion').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    this.categoriaService.getCategorias().subscribe(
      res => {
        this.categorias = res;
      }
    );
    const params = this.activeRoute.snapshot.params;
    this.equipoService.getDataEquipo(params.id)
      .subscribe(
        res => {
          console.log(res);
          this.equipo = res[0];
        },
        err => {console.error(err);
                swal.fire({
            title: this.textoError,
            text: this.textErrorServer,
            type: 'error',
            timer: 2500,
          });
        }
      );

  }
  updateEquipo() {
    this.translate.get('equipos_edit.edit_ok').subscribe(
      res => {
        this.textEditSuccess = res;
      }
    );
    this.translate.get('equipos_edit.edit_ko').subscribe(
      res => {
        this.textEditError = res;
      }
    );
    this.translate.get('club.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    // Si no quiero que modifique un dato delete this.user.dato
    this.equipoService.updateEquipo(this.equipo.id, this.equipo)
    .subscribe(
        res => {
          swal.fire({
            title: this.textEditSuccess,
            type: 'success',
            timer: 2500,
          });
          this.router.navigate(['/equipos', this.equipo.club]);
        },
        err => { console.log(err);
                 swal.fire({
          title: this.textEditError,
          text: this.textReview,
          type: 'error',
          timer: 2500,
        });
      }
    );
  }
}
