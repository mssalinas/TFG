export interface Club {
  ID?: number;
  nombre?: string;
  password?: string;
  direccion?: string;
  telefono?: number;
  url_web?: string;
  email?: string;
  campo_juego?: string;
  color_equipacion?: string;
  logo?: string;
}
