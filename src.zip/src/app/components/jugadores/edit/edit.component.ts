import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { JugadoresService } from 'src/app/services/jugadores.service';
import { Jugadores } from 'src/app/models/jugadores';
import swal from 'sweetalert2';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ClubsService } from 'src/app/services/clubs.service';
import { EquiposService } from 'src/app/services/equipos.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditJugadorComponent implements OnInit {

  jugador: Jugadores = {
  id: 0,
  club: null,
  equipo: null,
  DNI: '',
  nombre: '',
  apellidos: '',
  fecha_nacimiento: '',
  dorsal_juego: 0
  };
  edit = true;
  equipos: any = [];
  jugadores: any = [];
  club: string;

  activeLang = 'es';
  textErrorServer: string;
  textoError: string;
  textSearchError: string;
  textEditError: string;
  textEditSuccess: string;
  textSearchSuccess: string;
  textReview: string;

  constructor(private route: Router, private activeRoute: ActivatedRoute, private jugadoresService: JugadoresService,
              private form: FormBuilder, private clubService: ClubsService, private equipoService: EquiposService,
              private translate: TranslateService) {
                this.translate.setDefaultLang(this.activeLang);
  }
  ngOnInit() {// Parametros de la url
    this.translate.get('jugadores_edit.error_get').subscribe(
      res => {
        this.textoError = res;
      }
    );
    this.translate.get('arbitros.text_error').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    const params = this.activeRoute.snapshot.params;
    if (params.id) {
      this.jugadoresService.getJugador(params.id)
      .subscribe(
        res => {
          this.jugador = res;
          this.equipoService.getEquipoClub(this.jugador.club).subscribe(
            res => {
             this.equipos = res;
            }
          );
          this.clubService.getDataClub(this.jugador.club).subscribe(
            res => {
                this.club = res[0].nombre;
            }
          );
          this.equipoService.getDataEquipo(this.jugador.equipo).subscribe(
            res => {
              this.jugador.equipo = res[0].nombre;
            }
          );
        },
        err => {console.error(err);
                swal.fire({
            title: this.textoError,
            text: this.textErrorServer,
            type: 'error',
            timer: 2500,
          });
        }
      );
      } else {
        this.edit = false;
      }
  }

  updateJugador() {
    this.translate.get('jugadores_edit.edit_ko').subscribe(
      res => {
        this.textEditError = res;
      }
    );
    this.translate.get('jugadores_edit.edit_ok').subscribe(
      res => {
        this.textEditSuccess = res;
      }
    );
    this.translate.get('arbitros.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    this.jugadoresService.updateJugador(this.jugador.id, this.jugador)
    .subscribe(
        res => {
          swal.fire({
            title:  this.textEditSuccess,
            type: 'success',
            timer: 2500,
          });
          this.route.navigate(['/jugadores', this.jugador.club]);
        },
        err => { console.log(err);
                 swal.fire({
          title: this.textEditError,
          text: this.textReview,
          type: 'error',
          timer: 2500,
        });
      }
    );
  }

  searchJugador() {
    this.edit = false;
    this.translate.get('jugadores_edit.search_ko').subscribe(
      res => {
        this.textSearchError = res;
      }
    );
    this.translate.get('arbitros.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    this.jugadoresService.findJugador(this.jugador.DNI, this.jugador.nombre, this.jugador.apellidos, this.jugador.dorsal_juego,
      this.jugador.fecha_nacimiento, this.jugador.club, this.jugador.equipo).subscribe(
      res => {
          console.log(res);
          this.jugadores = res;
          this.route.navigate(['/jugadores']);
          this.jugadoresService.sendData(this.jugadores);
      },
      err => {
        console.log(err);
        swal.fire({
        title: this.textSearchError,
        text: this.textReview,
        type: 'warning',
        timer: 2500,
          });
      }
    );
  }
}
