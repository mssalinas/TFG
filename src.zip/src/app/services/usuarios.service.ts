import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

import {Usuario} from '../models/usuarios';
import { BehaviorSubject } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class UsuariosService {
  authSubject = new BehaviorSubject(false);

  private isUserLoggedIn;
  public usserLogged: Usuario;
  public toArray;

  API_URI = 'http://localhost:3000/api';

  constructor( private http: HttpClient) {
    this.isUserLoggedIn = false;
  }

  getUsuarios() {
    return this.http.get(`${this.API_URI}/arbitros`);
  }
  getUsuario(id: number) {
    return this.http.get(`${this.API_URI}/usuarios/${id}`);
  }
  deleteUsuario(id: number) {
    return this.http.delete(`${this.API_URI}/arbitros/${id}`);
  }
  saveUsuario(usuario: Usuario) {
    return this.http.post(`${this.API_URI}/arbitros`, usuario);
  }
  getArbitros() {
    return this.http.get(`${this.API_URI}/arbitros`);
  }
  getArbitro(id: string) {
    return this.http.get(`${this.API_URI}/arbitros/${id}`);
  }
  updateUsuario(id: number, updatedUsuario: Usuario) {
    return this.http.put(`${this.API_URI}/arbitros/${id}`, updatedUsuario);
  }
  getOficiales() {
    return this.http.get(`${this.API_URI}/oficiales_mesa`);
  }
  getOficial(id: string) {
    return this.http.get(`${this.API_URI}/oficiales_mesa/${id}`);
  }
  deleteOficial(id: string) {
    return this.http.delete(`${this.API_URI}/oficiales_mesa/${id}`);
  }
  saveOficial(usuario: Usuario) {
    return this.http.post(`${this.API_URI}/oficiales_mesa`, usuario);
  }
  updateOficial(id: number, updatedUsuario: Usuario) {
    return this.http.put(`${this.API_URI}/oficiales_mesa/${id}`, updatedUsuario);
  }
  getDataUser(email: string) {
    return this.http.get(`${this.API_URI}/usuarios/user/${email}`);
  }
  getUserLog(id: string) {
    let user =  this.http.get(`${this.API_URI}/arbitros/${id}`);
    if (user == null) {
       user = this.http.get(`${this.API_URI}/oficiales_mesa/${id}`);
    }
    return user;
  }
  setUserLoggedIn(user: Usuario) {
    this.isUserLoggedIn = true;
    this.usserLogged = user;
    localStorage.setItem('currentUser', JSON.stringify(user));
  }
  getUserLoggedIn() {
  	return localStorage.getItem('currentUser');
  }
  getDataArbitros(id: number) {
    return this.http.get(`${this.API_URI}/arbitros/${id}`);
  }
  getDataOficiales(id: number) {
    return this.http.get(`${this.API_URI}/oficiales_mesa/${id}`);
  }
  findArbitro(dni: string, nombre: string, apellidos: string, categoria: number, email: string, telefono: number,
              fecha: Date, iban: string) {
    return this.http.get(`${this.API_URI}/arbitros/find/?DNI=${dni}&NOMBRE=${nombre}&APELLIDOS=${apellidos}&CATEGORIA=${categoria}&EMAIL=${email}&TELEFONO=${telefono}&FECHA_NACIMIENTO=${fecha}&IBAN=${iban}`);
  }
  findOficiales(dni: string, nombre: string, apellidos: string, categoria: number, email: string, telefono: number,
    fecha: Date, iban: string) {
      return this.http.get(`${this.API_URI}/oficiales_mesa/find/?DNI=${dni}&NOMBRE=${nombre}&APELLIDOS=${apellidos}&CATEGORIA=${categoria}&EMAIL=${email}&TELEFONO=${telefono}&FECHA_NACIMIENTO=${fecha}&IBAN=${iban}`);
    }
  sendData(array: any) {
    this.toArray = array;
  }
  getData() {
    return this.toArray;
  }
  removeData() {
    this.toArray = [];
  }
}
