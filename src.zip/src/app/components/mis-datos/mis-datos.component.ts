import { Component, OnInit } from '@angular/core';
import { UsuariosService } from '../../services/usuarios.service';
import { CategoriasService } from '../../services/categorias.service';
import { ClubsService } from '../../services/clubs.service';
import { Usuario } from 'src/app/models/usuarios';
import { Club } from 'src/app/models/club';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-mis-datos',
  templateUrl: './mis-datos.component.html',
  styleUrls: ['./mis-datos.component.css']
})
export class MisDatosComponent implements OnInit {

  permiso: number;
  userlog: number;
  clublog: number;
  usserLogged: string;
  dataUser: Usuario ;

  usuarios: any = [];

  usuario: Usuario = {
    DNI: '',
    NOMBRE: '',
    APELLIDOS: '',
    PASSWORD: '',
    PERMISO: 0,
    CATEGORIA: 0,
    EMAIL: '',
    TELEFONO: 0,
    FECHA_NACIMIENTO: new Date(),
    IBAN: ''
  };

  club: Club = {
    ID: 0,
  nombre: '',
  password: '',
  direccion: '',
  telefono: 0,
  url_web: '',
  email: '',
  campo_juego: '',
  color_equipacion: '',
  logo: ''
  };

  activeLang = 'es';

  constructor(private usuariosService: UsuariosService, private clubService: ClubsService, private categoriaService: CategoriasService,
    private translate: TranslateService ) {
      this.translate.setDefaultLang(this.activeLang);
     }

  ngOnInit() {
    this.usserLogged = this.usuariosService.getUserLoggedIn();
    this.usuariosService.getDataUser(this.usserLogged).subscribe(
        res => {
            this.dataUser = res[0];
            this.userlog = res[0].ID;
            this.permiso = res[0].PERMISO;
            console.log(this.permiso);
            this.clublog = res[0].id;

            if ( this.permiso === 1 || this.permiso === 2 || this.permiso === 3 ) {
            this.usuariosService.getUsuario(this.userlog).subscribe(
                res => {
                  this.usuario = res;
                  this.categoriaService.getDataCategoria(this.usuario.CATEGORIA).subscribe(
                      resp => {
                       this.usuario.CATEGORIA = resp[0].CATEGORIA;
                       console.log(resp[0]);
                      }
                    );

                });
              }
            this.clubService.getDataClub(this.clublog).subscribe(
                res => {
                  this.club = res[0];
                }
              );

        }
    );
  }

}
