import { Component, OnInit, HostBinding, ViewChild, ElementRef } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { CategoriasService } from '../../services/categorias.service';
import { EquiposService } from '../../services/equipos.service';
import { Categoria } from 'src/app/models/categorias';
import { Equipo } from '../../models/equipo';
import { ActivatedRoute, Router } from '@angular/router';
import { ClubsService } from 'src/app/services/clubs.service';
import { Club } from 'src/app/models/club';
import swal from 'sweetalert2';
import { UsuariosService } from 'src/app/services/usuarios.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-equipos',
  templateUrl: './equipos.component.html',
  styleUrls: ['./equipos.component.css']
})
export class EquiposComponent implements OnInit {

  closeResult: string;

  usserLogged: string;
  permiso: number;

  categorias: any = [];
  equipos: any = [];
  equiposAux: any = [];
  club: Club;
  categoria: Categoria;
  equipo: Equipo = {
  id: 0,
  club: 0,
  nombre: '',
  categoria: 0,
  num_jugadores: 0
  };

  addForm: FormGroup;
  public activeLang = 'es';
  textAddSuccess: string;
  textAddError: string;
  textErrorServer: string;
  textoError: string;
  textReview: string;
  textSuccessDelete: string;
  textErrorDetele: string;
  textErrorCat: string;

  constructor(private equiposService: EquiposService, private categoriaService: CategoriasService, private activeRoute: ActivatedRoute,
              private clubService: ClubsService, private modalService: NgbModal, private router: Router,
              private usuariosService: UsuariosService, private form: FormBuilder, private translate: TranslateService) {
                this.addForm = this.form.group({
                  nombre: ['', [Validators.required]],
                  categoria: ['', [Validators.required]],
                  num_jugadores: ['', [Validators.required]],
                });
                this.translate.setDefaultLang(this.activeLang);
              }

  @HostBinding('class') classes = 'row';
  @ViewChild('alert') alert: ElementRef;

  ngOnInit() {
    this.translate.get('equipos.error_gets').subscribe(
      res => {
        this.textoError = res;
      }
    );
    this.translate.get('club.conexion').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    const params = this.activeRoute.snapshot.params.id;

    this.clubService.getDataClub(params).subscribe(
      res => {
      this.club = res[0].nombre;
      }
    );
    this.categoriaService.getCategorias().subscribe(
      res => {
        this.categorias = res;
      }
    );
    this.usserLogged = this.usuariosService.getUserLoggedIn();
    this.usuariosService.getDataUser(this.usserLogged).subscribe(
        res => {
            this.permiso = res[0].PERMISO;
        });
    this.equiposService.getEquipoClub(params).subscribe(
      res => {
        this.equipos = res;
        this.equipos.forEach((equipo) => {
          this.categoriaService.getDataCategoria(equipo.categoria).subscribe(
            res => {
              equipo.categoria = res[0].CATEGORIA;
              }
            );
          });
          }, err => {
            console.error(err);
            swal.fire({
              title: this.textoError,
              text: this.textErrorServer,
              type: 'error',
              timer: 2000,
            });
          }
        );
    }

    getEquiposCategoria() {
      this.translate.get('equipos.no_equi').subscribe(
        res => {
          this.textErrorCat = res;
        }
      );
      const param_url = this.activeRoute.snapshot.params.id;
      this.equiposService.getEquiposCategoria(this.equipo.categoria, param_url).subscribe(
        res => {
          this.equipos = res;
        }, err => {
          console.error(err);
          swal.fire({
            title: this.textErrorCat,
            type: 'warning',
            timer: 2000,
          });
        }
      );
    }
    saveEquipo() {
      this.translate.get('equipos.add_ok').subscribe(
        res => {
          this.textAddSuccess = res;
        }
      );
      this.translate.get('equipos.add_ko').subscribe(
        res => {
          this.textAddError = res;
        }
      );
      this.translate.get('club.revisa').subscribe(
        res => {
          this.textReview = res;
        }
      );
      this.equiposService.saveEquipo(this.equipo)
      .subscribe(
        res => {
          swal.fire({
            title: this.textAddSuccess,
            type: 'success',
            timer: 2000,
          });
          this.router.navigate(['/equipos', this.equipo.club]);
        },
        err => { console.log(err);
                 swal.fire({
                title: this.textAddError,
                text: this.textReview,
                type: 'error',
                timer: 2000,
              });
        }
      );
    }
    deleteEquipo(id: number) {
      this.translate.get('equipos.delete_ok').subscribe(
        res => {
          this.textSuccessDelete = res;
        }
      );
      this.translate.get('equipos.delete_ko').subscribe(
        res => {
          this.textErrorDetele = res;
        }
      );
      this.equiposService.deleteEquipo(id).subscribe(
        res => {
          swal.fire({
            title: this.textSuccessDelete,
            type: 'success',
            timer: 2000,
          });
          this.ngOnInit();
        },
        err => { console.log(err);
                 swal.fire({
              title: this.textErrorDetele,
              text: this.textReview,
              type: 'error',
              timer: 2000,
            });
        }
      );
    }
    // ----- CÓDIGO PARA EL MODAL ----

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }
}
