import { Component, OnInit, HostBinding, ViewChild, ElementRef } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Club } from 'src/app/models/club';
import { Router } from '@angular/router';
import { ClubsService } from '../../services/clubs.service';
import swal from 'sweetalert2';
import { isNullOrUndefined } from 'util';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-clubs',
  templateUrl: './clubs.component.html',
  styleUrls: ['./clubs.component.css']
})
export class ClubsComponent implements OnInit {

  clubs: any = [];
  clubes: any = [];
  random: number;
  closeResult: string;

  search = false;

  selectedFile: File;
  imageSrc: string | ArrayBuffer;

  club: Club = {
    nombre: '',
    password: '',
    direccion: '',
    telefono: 0,
    url_web: '',
    email: '',
    campo_juego: '',
    color_equipacion: '',
    // hora_juego: 0,
    logo: ''
  };
  addForm: FormGroup;

  activeLang = 'es';
  textAddSuccess: string;
  textAddError: string;
  textErrorServer: string;
  textoError: string;
  textReview: string;
  textSuccessDelete: string;
  textErrorDetele: string;
  textExt: string;
  textSelec: string;

  constructor( private route: Router, private modalService: NgbModal, private clubService: ClubsService, private form: FormBuilder,
    private translate: TranslateService) {
    this.addForm = this.form.group({
      direccion: ['', [Validators.required]],
      password: ['', [Validators.required]],
      nombre: ['', [Validators.required]],
      url_web: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email, Validators.minLength(7)]],
      campo_juego: ['', [Validators.required]],
      telefono: ['', [Validators.required]],
      color_equipacion: ['', [Validators.required]],
      file: ['', [Validators.required]]
    });
    this.translate.setDefaultLang(this.activeLang);
  }
  @ViewChild('alert') alert: ElementRef;
  @HostBinding('class') classes = 'row';

  ngOnInit() {

    this.clubes = this.clubService.getData();
    console.log(this.clubes.length);
    if (this.clubes.length === 0) {
      this.getData();
    } else {
      this.clubs = this.clubService.getData();
      this.clubService.removeData();
    }
  }
  // A través de este método obtendremos todos los equipos
  getData() {
    this.translate.get('club.get_errors').subscribe(
      res => {
        this.textoError = res;
      }
    );
    this.translate.get('club.conexion').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    this.clubService.getClubs().subscribe(
      res => {
        this.clubs = res;
        console.log(res);
      },
      err => { console.error(err);
               swal.fire({
                title: this.textoError,
                text: this.textErrorServer,
                type: 'error',
                timer: 2500,
              });
      }
    );
  }
  // Función que permitirá almacenar un equipo
  saveClub() {
    this.translate.get('club.add_ok').subscribe(
      res => {
        this.textAddSuccess = res;
      }
    );
    this.translate.get('club.error_add').subscribe(
      res => {
        this.textAddError = res;
      }
    );
    this.translate.get('club.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    this.clubService.saveClub(this.club)
    .subscribe(
      res => {
        swal.fire({
          title: this.textAddSuccess,
          type: 'success',
          timer: 2000,
        });
        this.route.navigate(['/clubs']);
      },
      err => { console.log(err);
               swal.fire({
              title: this.textAddError,
              text: this.textReview,
              type: 'error',
              timer: 2000,
            });
      }
    );
  }
 // Función que permitirá eliminar un equipo
  deleteClub(ID: string) {
    this.translate.get('club.delete_error').subscribe(
      res => {
        this.textErrorDetele = res;
      }
    );
    this.translate.get('club.delete_ok').subscribe(
      res => {
        this.textSuccessDelete = res;
      }
    );
    this.clubService.deleteClub(ID).subscribe(
      res => {
        console.log(res);
        this.getData();
        swal.fire({
          title: this.textSuccessDelete,
          type: 'success',
          timer: 2000,
        });
      },
      err => { console.log(err);
               swal.fire({
            title: this.textErrorDetele,
            text: this.textErrorServer,
            type: 'error',
            timer: 2000,
          });
      }
    );
  }
  fileSelected(event) {
    this.translate.get('mis_partidos.extension').subscribe(
      res => {
        this.textExt = res;
      }
    );
    this.translate.get('mis_partidos.selec').subscribe(
      res => {
        this.textSelec = res;
      }
    );
    this.selectedFile = event.target.files[0];

    if (event.target.files && event.target.files[0]) {
          const file = event.target.files[0];

          const reader = new FileReader();
          reader.onload = e => this.imageSrc = reader.result;

          reader.readAsDataURL(file);
       }
    const extensiones = ['jpg', 'jpeg', 'png', 'JPG', 'JPEG', 'JFIF', 'BMP', 'SVG'];
    const extensionArchivo = this.selectedFile.name.split('.').pop();
    if (!extensiones.includes(extensionArchivo)) {
      document.getElementById('btns').style.display = 'none';
      swal.fire({
        title: this.textExt,
        text: this.textSelec,
        type: 'error',
        timer: 2000,
      });
     } else {
       document.getElementById('btns').style.display = 'block';
     }
    }

  getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
  }
// -----CÓDIGO PARA MODAL ----

open(content) {
  this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    this.closeResult = `Closed with: ${result}`;
  }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  });
}
private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return  `with: ${reason}`;
  }
}
}
