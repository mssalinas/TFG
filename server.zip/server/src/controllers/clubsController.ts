import { Request, Response} from 'express';

import db from '../database';

class ClubesController  {
   
    public async listAll (req: Request,res: Response) {
        const clubs = await db.query('SELECT * from clubes');
         res.json(clubs);
     } 
     public async getCLub(req: Request,res: Response) : Promise<any>{
         const { id } = req.params;
         const club = await db.query('SELECT * from clubes where id= ? ', [id]);
         if (club.length > 0){
             return res.json(club);
         }
         res.status(404).json({text: 'Club no encontrado'});
     }
     public async create (req: Request,res: Response): Promise<void>{
        await db.query('INSERT INTO clubes set ?', [req.body]) 
         res.json({message: 'Club creado'});
     }
     public async delete (req: Request,res: Response){
         const {id} = req.params;
         await db.query('DELETE from clubes where id= ?', [id]);
         res.json({message: 'Club eliminado correctamente'});
     }
     public async  update (req: Request,res: Response){
        const {id} = req.params;
        console.log(req.body);
        await db.query('UPDATE clubes set ? WHERE id = ?', [req.body, id]);
        res.json({message:'Club actualizado correctamente'});
     }
     public async find (req: Request, res: Response){
        console.log('%'+req.query.nombre+'%');
        const club = await db.query('SELECT * FROM clubes WHERE nombre LIKE ? and direccion LIKE ? or telefono LIKE ? and url_web LIKE ? and email LIKE ? and campo_juego LIKE ? and color_equipacion LIKE ? ', 
        ['%'+req.query.nombre+'%', '%'+req.query.direccion+'%','%'+req.query.telefono+'%', '%'+req.query.url_web+'%', '%'+req.query.email+'%', '%'+req.query.campo_juego+'%', '%'+req.query.color_equipacion+'%']);
        if (club.length > 0){
          console.log(club.length);
          res.json(club);
        }else{
          console.log('not found')
          res.status(404).json({text: "No se han encontrado resultados de búsqueda"});
        }
     }
     public async search (req: Request,res: Response) : Promise<any>{
         console.log(req.query);
        const club = await db.query('SELECT * from clubes where nombre LIKE ?', [req.query.nombre]);
        if (club.length > 0){
            return res.json(club);
        }
        res.status(404).json({text: 'Club no encontrado'});
    }
    
}
export const clubesController  = new ClubesController();