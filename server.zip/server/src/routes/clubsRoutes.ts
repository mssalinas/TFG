import {Router} from 'express';
import { clubesController } from '../controllers/clubsController';

class ClubsRoutes{

    public router: Router = Router();

    constructor(){
        this.config();
    }
    config(): void{
        this.router.get('/', clubesController.listAll);
        this.router.get('/find', clubesController.find);
        this.router.get ('/:id', clubesController.getCLub);
        this.router.post ('/', clubesController.create);
        this.router.delete ('/:id', clubesController.delete);
        this.router.put('/:id', clubesController.update);
    }
}

const clubesRoutes= new ClubsRoutes();
export default clubesRoutes.router;