import { Time } from '@angular/common';

export interface Partido {
  id?: number;
  equipo_1?: number;
  equipo_2?: number;
  fecha?: Date;
  categoria?: number;
  hora?: Time;
  resultado?: string;
  arbitro_1?: number;
  arbitro_2?: number;
  arbitro_3?: number;
  oficial_1?: number;
  oficial_2?: number;
  oficial_3?: number;
  acta?: Blob;
}
