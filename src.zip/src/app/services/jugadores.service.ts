import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Jugadores } from '../models/jugadores';
@Injectable({
  providedIn: 'root'
})
export class JugadoresService {

  constructor(private http: HttpClient) { }

  API_URI = 'http://localhost:3000/api';
  arrayJugadores: any = [];

  getJugadores() {
    return this.http.get(`${this.API_URI}/jugadores`);
  }
  getJugador(id: number) {
    return this.http.get(`${this.API_URI}/jugadores/${id}`);
  }
  getJugadoresEquipo(id: number) {
    return this.http.get(`${this.API_URI}/jugadores/equipo/${id}`);
  }
  deleteJugador(id: number) {
    return this.http.delete(`${this.API_URI}/jugadores/${id}`);
  }
  saveJugador(jugador: Jugadores) {
    return this.http.post(`${this.API_URI}/jugadores`, jugador);
  }
  updateJugador(id: number, jugador: Jugadores) {
    return this.http.put(`${this.API_URI}/jugadores/${id}`, jugador);
  }
  findJugador(DNI: string, nombre: string, apellidos: string, dorsal_juego: number, fecha_nacimiento: string, club: number, equipo: number) {
    return this.http.get(`${this.API_URI}/jugadores/search/?DNI=${DNI}&nombre=${nombre}&apellidos=${apellidos}&dorsal_juego=${dorsal_juego}&fecha_nacimiento=${fecha_nacimiento}&club=${club}&equipo=${equipo}`);
  }
  sendData(array: any) {
    this.arrayJugadores = array;
  }
  getData() {
    return this.arrayJugadores;
  }
  removeData() {
    this.arrayJugadores = [];
  }
}
