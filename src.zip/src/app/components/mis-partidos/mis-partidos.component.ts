import {Component, OnInit, HostBinding} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { PartidosService } from '../../services/partidos.service';
import { ClubsService } from '../../services/clubs.service';
import { UsuariosService } from '../../services/usuarios.service';
import { Partido } from 'src/app/models/partido';
import * as jsPDF from 'jspdf';
import * as html2canvas from 'html2canvas';
import { EquiposService } from 'src/app/services/equipos.service';
import { Equipo } from 'src/app/models/equipo';
import swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'app-mis-partidos',
  templateUrl: './mis-partidos.component.html',
  styleUrls: ['./mis-partidos.component.css']
})
export class MisPartidosComponent implements OnInit {
  closeResult: string;

  partidos: any = [];
  i: number;
  equipos: any = [];
  categorias: any = [];
  arbitros: any = [];
  usserLogged: string;
  dataUser: any = [];
  permiso: number;
  equipo1: Equipo;
  equipo2: Equipo;
  userlog: number;
  now = new Date();
  selectedFile: File;
  imageSrc: string | ArrayBuffer;



  partido: any = {
    id:  0,
    equipo_1: 0,
    equipo_2: 0,
    fecha: new Date(),
    categoria: 0,
    resultado: '',
    arbitro_1: 0,
    arbitro_2: 0,
    arbitro_3: 0,
    oficial_1: 0,
    oficial_2: 0,
    oficial_3: 0,
    club1: 0,
    club2: 0,
    ubicacion: ''
  };

  partidores: Partido = {
   resultado: '',
   acta: null
  };

  activeLang = 'es';
  textExt: string;
  textImg: string;
  textErrorServer: string;
  textoError: string;
  textReview: string;
  textSuccessDelete: string;
  textErrorDetele: string;

  constructor( private route: Router, private partidoService: PartidosService,
               private clubService: ClubsService, private activeRoute: ActivatedRoute, private equipoService: EquiposService,
               private usuariosService: UsuariosService, private modalService: NgbModal, private translate: TranslateService) {
                this.translate.setDefaultLang(this.activeLang);
               }
  @HostBinding('class') classes = 'row';

  ngOnInit() {
    this.translate.get('mis_partidos.error').subscribe(
      res => {
        this.textoError = res;
      }
    );
    this.translate.get('partidos.revisa').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    // En primer lugar, obtendremos todos los equipos
    this.equipoService.getEquipos().subscribe(
      res => {
        this.equipos = res;
      }
    );
    this.usuariosService.getArbitros().subscribe(
      res => {
      this.arbitros = res;
      }
    );
    this.usserLogged = this.usuariosService.getUserLoggedIn();
    this.usuariosService.getDataUser(this.usserLogged).subscribe(
        res => {
            this.dataUser = res[0];
            this.userlog = res[0].ID;
            this.permiso = res[0].PERMISO;
    // Finalmente recuperaremos los datos a mostrar de cada partido
            this.partidoService.getmisPartidosSemana(this.userlog).subscribe(
      res => {
        this.partidos = res;
        this.partidos.forEach((partido) => {
        this.partidoService.getDataEquipo(partido.equipo_1).subscribe(
          res => {
            partido.equipo_1 = res[0];
            this.equipo1 = res[0];

            this.clubService.getDataClub(this.equipo1.club).subscribe(
               res => {
              partido.club1 = res[0].logo;
              partido.ubicacion = res[0].direccion;
                    }
                );
          }
        );
        this.partidoService.getDataEquipo(partido.equipo_2).subscribe(
          res => {
            partido.equipo_2 = res[0];
            this.equipo2 = res[0];
            this.clubService.getDataClub(this.equipo2.club).subscribe(
               res => {
                 partido.club2 = res[0].logo;
                    }
                );
          }
        );
        this.usuariosService.getDataArbitros(partido.arbitro_1).subscribe(
           res => {
             partido.arbitro_1 = res[0];
           }
         );
        this.usuariosService.getDataArbitros(partido.arbitro_2).subscribe(
          res => {
            partido.arbitro_2 = res[0];
          }
        );
        this.usuariosService.getDataArbitros(partido.arbitro_3).subscribe(
          res => {
            partido.arbitro_3 = res[0];
          }
        );
        this.usuariosService.getDataOficiales(partido.oficial_1).subscribe(
          res => {
            partido.oficial_1 = res[0];
          }
        );
        this.usuariosService.getDataOficiales(partido.oficial_2).subscribe(
          res => {
            partido.oficial_2 = res[0];
          }
        );
        this.usuariosService.getDataOficiales(partido.oficial_3).subscribe(
          res => {
            partido.oficial_3 = res[0];
          }
        );
        });
      },
      err => { console.error(err);
            //   swal('¡Se ha porducido un error obtiendo los partidos!', 'Revisa la conexión', 'error');
               swal.fire({
              title: this.textoError,
              text: this.textErrorServer,
              type: 'error',
              timer: 2000,
            });
          }
    );
  });
  }
  fileSelected(event) {
    this.translate.get('mis_partidos.extension').subscribe(
      res => {
        this.textExt = res;
      }
    );
    this.translate.get('mis_partidos.select').subscribe(
      res => {
        this.textImg = res;
      }
    );
    this.selectedFile = event.target.files[0];

    if (event.target.files && event.target.files[0]) {
          const file = event.target.files[0];

          const reader = new FileReader();
          reader.onload = e => this.imageSrc = reader.result;

          reader.readAsDataURL(file);
       }
    console.log(this.selectedFile.name);
    const extensiones = ['jpg', 'jpeg', 'png', 'JPG', 'JPEG', 'JFIF', 'BMP', 'SVG'];
    const extensionArchivo = this.selectedFile.name.split('.').pop();
    if (!extensiones.includes(extensionArchivo)) {
      document.getElementById('btns').style.display = 'none';
      swal.fire({
        title: this.textExt,
        text: this.textImg,
        type: 'error',
        timer: 2000,
      });
     } else {
       document.getElementById('btns').style.display = 'block';
     }
    }

     download(i: number) {
      console.log(i);
      document.getElementById('templatepdf').style.display = 'block';
      const data = document.getElementById('templatepdf');
      html2canvas(data).then(canvas => {
      // Few necessary setting options
      const imgWidth = 208;
      const pageHeight = 295;
      const imgHeight = canvas.height * imgWidth / canvas.width;
      const heightLeft = imgHeight;
      const contentDataURL = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4'); // A4 size page of PDF
      const position = 0;
      pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight);
      pdf.save('partidos' + this.userlog + '.pdf'); // Generated PDF
      document.getElementById('templatepdf').style.display = 'none';
    });
  }
  updatePartido() {
    this.translate.get('partidos_edit.edit_nook').subscribe(
      res => {
        this.textErrorDetele = res;
      }
    );
    const fd = new FormData();
    fd.append('image', this.selectedFile, this.selectedFile.name);
    this.partidoService.updatePartido(this.partidores.id, this.partidores)
    .subscribe(
        event => {
          this.route.navigate(['/misPartidos/']);
        },
        err => {console.log(err);
            //    swal('¡Se ha porducido un error al actualizar !', 'Revisa los datos introducidos', 'error');
                swal.fire({
              title: this.textErrorDetele,
              text: this.textReview,
              type: 'error',
              timer: 2000,
            });
          }
    );
  }
   // -----CÓDIGO PARA MODAL ----

   open(content, id: number) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
    this.partidoService.getPartido(id).subscribe(
      res => {
        this.partidores = res;
        console.log(this.partidores.id);
      });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }
}
