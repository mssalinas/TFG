import {Router} from 'express';
import { authController } from '../controllers/authController';

class AuthRouter{

    public router: Router = Router();

    constructor(){
        this.config();
    }
    config(): void{ 
       this.router.post('/', authController.login);
    }
}

const authRoutes = new AuthRouter();
export default authRoutes.router;