import {Router} from 'express';
import { categoriasController } from '../controllers/categoriasController';

class CategoriasRoutes {

    public router: Router = Router();

    constructor(){
        this.config();
    }
    config(): void{ 
       this.router.get('/', categoriasController.getAll);
       this.router.get ('/:id', categoriasController.getDataCategoria);
       this.router.get('/club/:id', categoriasController.getCategoriasClub);
    }
}

const categoriasRoutes = new CategoriasRoutes();
export default categoriasRoutes.router;