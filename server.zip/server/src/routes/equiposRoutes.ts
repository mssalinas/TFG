import {Router} from 'express';
import { equiposController } from '../controllers/equiposController';

class EquiposRoutes{

    public router: Router = Router();

    constructor(){
        this.config();
    }
    config(): void {
         this.router.get ('/', equiposController.getAll);
         this.router.get ('/:id', equiposController.getDataEquipo);
         this.router.get('/club/:id', equiposController.getEquiposClub);
         this.router.get('/categoria/:id', equiposController.getEquiposClubCategoria);
         this.router.delete('/:id', equiposController.deleteEquipo)
         this.router.put('/:id', equiposController.update);
         this.router.post ('/', equiposController.create);
        
    }
}

const equiposRoutes = new EquiposRoutes();
export default equiposRoutes.router;