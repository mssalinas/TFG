import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OficialesEditComponent } from './oficiales-edit.component';

describe('OficialesEditComponent', () => {
  let component: OficialesEditComponent;
  let fixture: ComponentFixture<OficialesEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OficialesEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OficialesEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
