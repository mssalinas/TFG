import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CategoriasService {

  constructor(private http: HttpClient) { }

  API_URI = 'http://localhost:3000/api';

  getCategorias() {
    return this.http.get(`${this.API_URI}/categorias`);
  }
  getDataCategoria(id: number) {
    return this.http.get(`${this.API_URI}/categorias/${id}`);
  }
  getCategoriasClub(id: number) {
    return this.http.get(`${this.API_URI}/club/${id}`);
  }
}
