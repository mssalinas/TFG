import { Request, Response } from "express";

import db from "../database";

class JugadoresController {

  public async listAll(req: Request, res: Response) {
    const partidos = await db.query("SELECT * from jugadores");
    res.json(partidos);
  }
  public async getJugadoresEquipos(req: Request, res: Response): Promise<any> {
    const { id } = req.params;
    const partido = await db.query("SELECT * from jugadores where equipo= ? ORDER BY dorsal_juego", [id]);
    if (partido.length > 0) {
      return res.json(partido);
    }
    res.status(404).json({ text: "Jugadores no encontrados" });
  }
  public async getJugador(req: Request, res: Response): Promise<any> {
    const { id } = req.params;
    const partido = await db.query("SELECT * from jugadores where id= ? ORDER BY nombre", [id]);
    if (partido.length > 0) {
      return res.json(partido[0]);
    }
    res.status(404).json({ text: "Jugador no encontrado" });
  }
  public async create(req: Request, res: Response): Promise<void> {
    await db.query("INSERT INTO jugadores set ?", [req.body]);
    res.json({ message: "Jugador añadido correctamente" });
  }
  public async delete(req: Request, res: Response) {
    const { id } = req.params;
    await db.query("DELETE from jugadores where id= ?", [id]);
    res.json({ message: "Jugador eliminado correctamente" });
  }
  public async update(req: Request, res: Response) {
    const { id } = req.params;
    console.log(id);
    const partido = await db.query("SELECT * from jugadores WHERE id = ?", [id]);
    if (partido.length > 0) {
      await db.query("UPDATE jugadores set ? WHERE id = ?", [req.body, id]);
      res.json({ message: "Jugador actualizado correctamente" });
    } else {
      res.json({ message: "El jugador no existe en la base de datos" });
    }
  }
  public async find(req: Request, res: Response) {
    console.log('%'+req.query.nombre+'%');
        const jugador = await db.query('SELECT * FROM jugadores WHERE DNI LIKE ? and nombre LIKE ? and apellidos LIKE ? or dorsal_juego LIKE ? and fecha_nacimiento LIKE ? and club LIKE ? and equipo LIKE ?', 
        ['%'+req.query.DNI+'%', '%'+req.query.nombre+'%','%'+req.query.apellidos+'%', '%'+req.query.dorsal_juego+'%','%'+req.query.fecha_nacimiento+'%', '%'+req.query.club+'%', '%'+req.query.equipo+'%']);
        if (jugador.length > 0){
          console.log(jugador.length);
          res.json(jugador);
        }else{
          console.log('not found')
          res.status(404);
        }
  }
}
export const jugadoresController = new JugadoresController();
