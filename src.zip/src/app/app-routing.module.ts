import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ArbitrosComponent } from './components/usuarios/arbitros/arbitros.component';
import { UsuariosListComponent } from './components/usuarios/usuarios-list/usuarios-list.component';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { OficialesMesaComponent } from './components/usuarios/oficiales-mesa/oficiales-mesa.component';
import { EditComponent } from './components/usuarios/arbitros/edit_arbitro/edit.component';
import { OficialesEditComponent } from './components/usuarios/oficiales-mesa/oficiales-edit/oficiales-edit.component';
import { ClubsComponent } from './components/clubs/clubs.component';
import { PartidosComponent } from './components/partidos/partidos.component';
import { DisponibilidadComponent } from './components/disponibilidad/disponibilidad.component';
import { DesignacionesComponent } from './components/designaciones-arbitros/designaciones.component';
import { DesignacionesOficialesComponent } from './components/designaciones-oficiales/designaciones-oficiales.component';
import { MisPartidosComponent } from './components/mis-partidos/mis-partidos.component';
import { ContabilidadComponent } from './components/contabilidad/contabilidad.component';
import { EquiposComponent } from './components/equipos/equipos.component';

import {LoginGuard} from './guards/login.guard';
import { JugadoresComponent } from './components/jugadores/jugadores.component';
import { ContabilidadClubComponent } from './components/contabilidad-club/contabilidad-club.component';
import { MisDatosComponent } from './components/mis-datos/mis-datos.component';
import { MiNoDispComponent } from './components/mi-no-disp/mi-no-disp.component';
import { EditJugadorComponent } from './components/jugadores/edit/edit.component';
import { EditClubComponent } from './components/clubs/edit-club/edit-club.component';
import { EditPartidosComponent } from './components/partidos/edit/edit.component';
import { CanActivate } from '@angular/router/src/utils/preactivation';
import { EditEquipoComponent } from './components/equipos/edit-equipo/edit-equipo.component';
import { EmailComponent } from './components/email/email.component';

const routes: Routes = [
  {
    // Lista ruta inicial
    path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    component: HomeComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'usuarios',
    component: UsuariosListComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'usuarios/appoint/arbitros',
    component: DesignacionesComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'usuarios/appoint/oficiales_mesa',
    component: DesignacionesOficialesComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'oficiales_mesa',
    component : OficialesMesaComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'arbitros',
    component: ArbitrosComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'arbitros/edit/:id',
    component : EditComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'arbitros/search',
    component: EditComponent,
    canActivate: [LoginGuard]
  },
   {
    path: 'oficiales_mesa/search',
    component: OficialesEditComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'oficiales_mesa/edit/:id',
    component : OficialesEditComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'clubs',
    component: ClubsComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'partidos',
    component: PartidosComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'misPartidos',
    component: MisPartidosComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'disponibilidad',
    component: DisponibilidadComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'contabilidad',
    component: ContabilidadComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'equipos/:id',
    component: EquiposComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'equipos/edit/:id',
    component: EditEquipoComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'jugadores',
    component: JugadoresComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'jugadores/:id',
    component: JugadoresComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'contabilidad_club',
    component: ContabilidadClubComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'midata',
    component: MisDatosComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'minodisp',
    component: MiNoDispComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'jugadores/edit/:id',
    component : EditJugadorComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'search',
    component: EditJugadorComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'clubs/edit/:id',
    component: EditClubComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'clubs/search',
    component: EditClubComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'partidos/edit/:id',
    component: EditPartidosComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'partidos/search',
    component: EditPartidosComponent,
    canActivate: [LoginGuard]
  },
  {
    path: 'contactos',
    component: EmailComponent,
    canActivate: [LoginGuard]
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
