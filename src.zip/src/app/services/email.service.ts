import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Email } from '../models/email';
@Injectable({
  providedIn: 'root'
})
export class EmailService {

  constructor(private http: HttpClient) { }

  API_URI = 'http://localhost:3000/api';

  sendEmail(email: Email) {
    return this.http.post(`${this.API_URI}/contactos`, email);
  }
}
