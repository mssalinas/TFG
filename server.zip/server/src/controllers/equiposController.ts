import { Request, Response } from "express";

import db from "../database";

class EquiposController {
    
  public async getAll(req: Request, res: Response): Promise<void> {
    const equipos = await db.query("SELECT * from equipos");
    res.json(equipos);
  }

  public async getEquiposClub(req: Request, res: Response) {
    const { id } = req.params;
    const equipos = await db.query("SELECT * from equipos where club= ? ", [
      id
    ]);
    if (equipos.length > 0) {
      return res.json(equipos);
    }
    res.status(404).json({ text: "Equipos no encontrados" });
  }
  public async deleteEquipo (req: Request, res: Response) {
    const { id } = req.params;
    await db.query("DELETE from equipos where id= ?", [id]);
    res.json({ message: "Equipo eliminado correctamente" });
  }
  public async getDataEquipo(req: Request,res: Response){
    const { id } = req.params;
    const equipo = await db.query('SELECT * from equipos where id= ? ', [id]);
    if (equipo.length > 0){
        return res.json(equipo);
    }
    res.status(404).json({text: 'Equipo no encontrado'});
} 
  
  public async getEquiposClubCategoria(req: Request, res: Response) {
    const equipos = await db.query('SELECT * from equipos where categoria= ? and club= ? ', [req.params.id, req.query.club]);
    if (equipos.length > 0) {
        return res.json(equipos);
      }
     res.status(404).json({ text: "No se han encontardo equipos en esa categoria" });
  }
  public async create(req: Request, res: Response): Promise<void> {
  await db.query("INSERT INTO equipos set ?", [req.body]);
  res.json({ message: "Equipo añadido correctamente" });
  } 

  public async update(req: Request, res: Response) {
  const { id } = req.params;
  const partido = await db.query("SELECT * from equipos WHERE id = ?", [id]);
  if (partido.length > 0) {
    await db.query("UPDATE equipos set ? WHERE id = ?", [req.body, id]);
    res.json({ message: "Equipo actualizado correctamente" });
  } else {
    res.json({ message: "El equipo no existe en la base de datos" });
  }
}
}
export const equiposController = new EquiposController();
