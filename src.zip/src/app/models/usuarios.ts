export interface Usuario {
  ID?: number;
  DNI?: string;
  PASSWORD?: string;
  NOMBRE?: string;
 APELLIDOS?: string;
 PERMISO?: number;
 CATEGORIA?: number;
 EMAIL?: string;
 TELEFONO?: number;
 FECHA_NACIMIENTO?: Date;
 IBAN?: string;
// Para que el campo pueda venir al null id?: number
}
