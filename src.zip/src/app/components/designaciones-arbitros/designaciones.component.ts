import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { PartidosService } from '../../services/partidos.service';
import { ClubsService } from '../../services/clubs.service';
import { CategoriasService } from '../../services/categorias.service';
import { EquiposService } from '../../services/equipos.service';
import swal from 'sweetalert2';
import { Equipo } from '../../models/equipo';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-designaciones',
  templateUrl: './designaciones.component.html',
  styleUrls: ['./designaciones.component.css']
})
export class DesignacionesComponent implements OnInit {
  closeResult: string;
  partidos: any = [];
  equipos: any = [];
  categorias: any = [];
  arbitros: any = [];
  oficales: any = [];
  equipo1: Equipo;
  equipo2: Equipo;
  partido: any = {
    id: 0,
    arbitro_1: 0,
    arbitro_2: 0,
    arbitro_3: 0,
    club_1: '',
    club_2: '',
  };
  textAddSuccess: string;
  textAddError: string;
  textErrorServer: string;
  textoError: string;
  textReview: string;
  public activeLang = 'es';
  partido2: any;
  constructor( private partidoService: PartidosService,  private modalService: NgbModal,
               private equipoService: EquiposService, private categoriaService: CategoriasService,
               private translate: TranslateService) {
                this.translate.setDefaultLang(this.activeLang);
                }

  ngOnInit() {
    this.getData();
  }

  // A través de este método obtendremos los datos neesarios a mostrar de los partidos
  getData() {
    this.translate.get('designaciones.error').subscribe(
      res => {
        this.textoError = res;
      }
    );
    this.translate.get('club.conexion').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    // En primer lugar, obtendremos todos los equipos
    this.equipoService.getEquipos().subscribe(
      res => {
        this.equipos = res;
      }
    );
    this.partidoService.getPartidos().subscribe(
      res => {
       // console.log(res);
       this.partidos = res;
       this.partidos.forEach((partido) => {
        this.partidoService.getDataEquipo(partido.equipo_1).subscribe(
         res => {
           partido.equipo_1 = res[0];
         }
       );
        this.partidoService.getDataEquipo(partido.equipo_2).subscribe(
         res => {
           partido.equipo_2 = res[0];
            }
       );
        this.categoriaService.getDataCategoria(partido.categoria).subscribe(
         res => {
          partido.categoria = res[0];
         }
       );
       });
    },
      err => {
        console.error(err);
        swal.fire({
        title: this.textoError,
        text: this.textErrorServer,
        type: 'error',
        timer: 2000,
      });
    }
    );
  }

  saveDesignacionArbitros(id: number) {
    this.translate.get('designaciones.ok').subscribe(
      res => {
        this.textAddSuccess = res;
      }
    );
    this.translate.get('designaciones.error2').subscribe(
      res => {
        this.textAddError = res;
      }
    );
    this.translate.get('club.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    this.partidoService.updatePartido(id, this.partido)
    .subscribe(
        res => {
          swal.fire({
            title: this.textAddSuccess,
            type: 'success',
            timer: 2000,
          });
        },
        err => { console.log(err);
                 swal.fire({
              title: this.textAddError,
              text: this.textReview,
              type: 'error',
              timer: 2000,
            });
            }
    );
  }

  // ----- CÓDIGO PARA EL MODAL ----
  open(content: any, id: number, idcategoria: number) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
    this.partidoService.getPartido(id).subscribe(
      res => {
        this.partido = res;
      });
    this.partidoService.getDataArbitrosCategoria(idcategoria, id).subscribe(
        res => {
        this.arbitros = res;
        }
      );
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }


}
