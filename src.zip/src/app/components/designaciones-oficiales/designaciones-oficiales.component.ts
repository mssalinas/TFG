import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { PartidosService } from '../../services/partidos.service';
import { CategoriasService } from '../../services/categorias.service';
import { EquiposService } from '../../services/equipos.service';

import { Partido } from '../../models/partido';
import swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-designaciones-oficiales',
  templateUrl: './designaciones-oficiales.component.html',
  styleUrls: ['./designaciones-oficiales.component.css']
})
export class DesignacionesOficialesComponent implements OnInit {
  closeResult: string;
  partidos: any = [];
  equipos: any = [];
  categorias: any = [];
  arbitros: any = [];
  oficales: any = [];

  partido: Partido = {
    id: 0,
    arbitro_1: 0,
    arbitro_2: 0,
    arbitro_3: 0,
  };
  textAddSuccess: string;
  textAddError: string;
  textErrorServer: string;
  textoError: string;
  textReview: string;
  public activeLang = 'es';

  constructor( private partidoService: PartidosService,  private modalService: NgbModal,
               private equipoService: EquiposService, private categoriaService: CategoriasService,
               private translate: TranslateService) {
                this.translate.setDefaultLang(this.activeLang);
                }
  @ViewChild('alert') alert: ElementRef;

  ngOnInit() {
    this.translate.get('designaciones.error').subscribe(
      res => {
        this.textoError = res;
      }
    );
    this.translate.get('club.conexion').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    // En primer lugar, obtendremos todos los equipos
    this.equipoService.getEquipos().subscribe(
      res => {
        this.equipos = res;
      }
    );
    // A continuación obtendremos las categorias
    this.categoriaService.getCategorias().subscribe(
      res => {
        this.categorias = res;
      }
    );
    this.partidoService.getPartidos().subscribe(
      res => {
       // console.log(res);
       this.partidos = res;
       this.partidos.forEach((partido) => {
        this.partidoService.getDataEquipo(partido.equipo_1).subscribe(
         res => {
           partido.equipo_1 = res[0];
         }
       );
        this.partidoService.getDataEquipo(partido.equipo_2).subscribe(
         res => {
           partido.equipo_2 = res[0];
         }
       );
        this.categoriaService.getDataCategoria(partido.categoria).subscribe(
         res => {
          partido.categoria = res[0];
          console.log(partido.categoria);
         }
       );


       });
    },
      err => { console.error(err);
           //    swal('¡Se ha porducido un error al obtener los datos de los partidos!', 'Revisa la conexión con el servidor', 'error');
               swal.fire({
                title: this.textoError,
                text: this.textErrorServer,
                type: 'error',
                timer: 2000,
          });
          }
    );
  }

  saveDesignacionesOficiales(id: number) {
    this.translate.get('designaciones.ok').subscribe(
      res => {
        this.textAddSuccess = res;
      }
    );
    this.translate.get('designaciones.error2').subscribe(
      res => {
        this.textAddSuccess = res;
      }
    );
    this.translate.get('club.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    this.partidoService.updatePartido(id, this.partido)
    .subscribe(
        res => {
          console.log(res);
        },
        err => {
          console.log(err);
        //  swal('¡Se ha porducido un error al guardar la designación!', 'Revisa los datos', 'error');
          swal.fire({
          title: this.textAddError,
          text: this.textReview,
          type: 'error',
          timer: 3000,
        });
      }
    );
   }

  // ----- CÓDIGO PARA EL MODAL ----
  open(content: any, id: number, idcategoria: number) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
    this.partidoService.getPartido(id).subscribe(
      res => {
        this.partido = res;
      });
    this.partidoService.getDataOficialesCategoria(idcategoria, id).subscribe(
      res => {
        this.oficales = res;
      });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }


}
