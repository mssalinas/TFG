import { Component, OnInit, HostBinding, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { PartidosService } from '../../services/partidos.service';
import { ClubsService } from '../../services/clubs.service';
import { CategoriasService } from '../../services/categorias.service';
import { UsuariosService } from '../../services/usuarios.service';
import { EquiposService } from '../../services/equipos.service';
import swal from 'sweetalert2';
import { Equipo } from 'src/app/models/equipo';
import { Partido } from 'src/app/models/partido';
import { DatePipe } from '@angular/common';
import { isNullOrUndefined } from 'util';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-partidos',
  templateUrl: './partidos.component.html',
  styleUrls: ['./partidos.component.css']
})
export class PartidosComponent implements OnInit {
  closeResult: string;

  partidosT: any = [];
  partidosE: any = [];
  partidos: any = [];
  partidosclub: any = [];
  i: number;
  equipos: any = [];
  categorias: any = [];
  arbitros: any = [];
  equipo1: Equipo;
  equipo2: Equipo;
  permiso: number;
  userlog: number;
  usserLogged: string;
  equipo: Equipo = {
    id: 0,
    club: 0,
    nombre: '',
    categoria: 0,
    num_jugadores: 0
  };

  equiposclub: any = [];
  partidosAux: any = [];
  partido: any = {
    id: 0,
    equipo_1: 0,
    equipo_2: 0,
    fecha: DatePipe,
    categoria: 0,
    resultado: '',
    arbitro_1: 0,
    arbitro_2: 0,
    arbitro_3: 0,
    club_1: '',
    club_2: ''
  };
  partidoI: Partido;

  addForm: FormGroup;

  activeLang = 'es';

  textAddSuccess: string;
  textAddError: string;
  textErrorServer: string;
  texErrorEq: string;
  texErrorPar: string;
  texErrorPar2: string;
  textReview: string;
  textSuccessDelete: string;
  textErrorDetele: string;

  constructor( private route: Router, private partidoService: PartidosService,  private modalService: NgbModal,
               private clubService: ClubsService, private equipoService: EquiposService, private categoriaService: CategoriasService,
               private usuariosService: UsuariosService, private form: FormBuilder, private translate: TranslateService) {
                this.addForm = this.form.group({
                  categoria: ['', [Validators.required]],
                  equipo_1: ['', [Validators.required]],
                  equipo_2: ['', [Validators.required]],
                  fecha: ['', [Validators.required]],
                  hora: ['', [Validators.required]]
                });
                this.translate.setDefaultLang(this.activeLang);
              }

  @HostBinding('class') classes = 'row';

  @ViewChild('alert') alert: ElementRef;

  ngOnInit() {
    this.translate.get('partidos.error_equip').subscribe(
      res => {
        this.texErrorEq = res;
      }
    );
    this.translate.get('partidos.error_server').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    this.translate.get('partidos.error_partido').subscribe(
      res => {
        this.texErrorPar = res;
      }
    );
    if (this.partidos.length > 0) {
        this.partidos.array.forEach((partido) => {
          this.partidoService.getDataEquipo(partido.equipo_1).subscribe(
            res => {
              partido.equipo_1 = res[0];
              this.equipo1 = res[0];
              this.clubService.getDataClub(this.equipo1.club).subscribe(
                 res => {
                 partido.club_1 = res[0].logo;
                      }, err => {
                        console.error(err);
                     }
                  );
                }, err => {
                  console.error(err);
                }
          );
          this.partidoService.getDataEquipo(partido.equipo_2).subscribe(
            res => {
              partido.equipo_2 = res[0];
              this.equipo2 = res[0];
              this.clubService.getDataClub(this.equipo2.club).subscribe(
                 res => {
                   partido.club_2 = res[0].logo;
                      }, err => {
                        console.error(err);
                      }
                  );
                }
            );

          this.usuariosService.getDataArbitros(partido.arbitro_1).subscribe(
             res => {
               console.log(res[0]);
               partido.arbitro_1 = res[0];
             }
           );
          this.usuariosService.getDataArbitros(partido.arbitro_2).subscribe(
            res => {

              partido.arbitro_2 = res[0];
            }
          );
          this.usuariosService.getDataArbitros(partido.arbitro_3).subscribe(
            res => {

              partido.arbitro_3 = res[0];
            }
          );
        });
    }
    this.partidosAux = this.partidoService.getData();
    const value = isNullOrUndefined(this.partidosAux);
    if (value) {
    this.equipoService.getEquipos().subscribe(
      res => {
        this.equipos = res;
      }
    );
    // A continuación obtendremos las categorias
    this.categoriaService.getCategorias().subscribe(
      res => {
        this.categorias = res;
      }
    );
    this.usuariosService.getArbitros().subscribe(
      res => {
      this.arbitros = res;
      }
    );
    this.usserLogged = this.usuariosService.getUserLoggedIn();
    this.usuariosService.getDataUser(this.usserLogged).subscribe(
      res => {
          this.userlog = res[0].id;
          this.permiso = res[0].PERMISO;
          console.log(this.permiso);
          if (this.permiso !== 1) {
          this.equipoService.getEquipoClub(this.userlog).subscribe(
            res => {
              console.log(res);
              this.equiposclub = res;
            }
          );
          this.categoriaService.getCategoriasClub(this.userlog).subscribe(
            res => {
              console.log(res);
              this.categorias = res;
            }
          );
          this.partidoService.getPartidosClub(this.userlog).subscribe(
        res => {
          console.log(res);
          this.partidosT = res;
          for (let i = 0; i < this.partidosT.length ; i++) {
            this.partidosE = res[i];
            if (this.partidosE.length === 1) {
               this.partidos.push(this.partidosE[0]);
            } else {
              for (let j = 0; j < this.partidosE.length; j++) {
              console.log(this.partidosE[j]);
              this.partidos.push(this.partidosE[j]);
            }
          }
          }
          this.partidos.forEach((partido) => {
              this.partidoService.getDataEquipo(partido.equipo_1).subscribe(
               res => {
                 partido.equipo_1 = res[0];
                 this.equipo1 = res[0];
                 this.clubService.getDataClub(this.equipo1.club).subscribe(
                    res => {
                    partido.club_1 = res[0].logo;
                         }, err => {
                           console.error(err);
                        }
                     );
                   }, err => {
                     console.error(err);
                   }
             );
              this.partidoService.getDataEquipo(partido.equipo_2).subscribe(
               res => {
                 partido.equipo_2 = res[0];
                 this.equipo2 = res[0];
                 this.clubService.getDataClub(this.equipo2.club).subscribe(
                    res => {
                      partido.club_2 = res[0].logo;
                         }, err => {
                           console.error(err);
                         }
                     );
                   }
               );

              this.usuariosService.getDataArbitros(partido.arbitro_1).subscribe(
                res => {
                  console.log(res[0]);
                  partido.arbitro_1 = res[0];
                }
              );
              this.usuariosService.getDataArbitros(partido.arbitro_2).subscribe(
               res => {

                 partido.arbitro_2 = res[0];
               }
             );
              this.usuariosService.getDataArbitros(partido.arbitro_3).subscribe(
               res => {

                 partido.arbitro_3 = res[0];
               }
             );
             });
        }, err => {
          console.error(err);
          swal.fire({
            title: this.texErrorEq,
            text: this.textReview,
            type: 'error',
            timer: 3000,
          });
        }
      );
    }
    // Finalmente recuperaremos los datos a mostrar de cada partido
          this.partidoService.getPartidos().subscribe(
      res => {
        console.log(res);
        this.partidos = res;
        this.partidos.forEach((partido) => {
        this.partidoService.getDataEquipo(partido.equipo_1).subscribe(
          res => {
            partido.equipo_1 = res[0];
            this.equipo1 = res[0];
            this.clubService.getDataClub(this.equipo1.club).subscribe(
               res => {
               partido.club_1 = res[0].logo;
                    }, err => {
                      console.error(err);
                  //    swal('¡Se ha porducido al obtener el logo del equipo local!', 'Revisa la conexión con el servidor', 'error');
                }
                );
              }, err => {
                console.error(err);
                // swal('¡Se ha porducido un error al obtener los datos del equipo local!', 'Revisa la conexión con el servidor', 'error');
              }
        );
        this.partidoService.getDataEquipo(partido.equipo_2).subscribe(
          res => {
            partido.equipo_2 = res[0];
            this.equipo2 = res[0];
            this.clubService.getDataClub(this.equipo2.club).subscribe(
               res => {
                 partido.club_2 = res[0].logo;
                    }, err => {
                      console.error(err);
                    }
                );
              }
          );
        this.usuariosService.getDataArbitros(partido.arbitro_1).subscribe(
           res => {
             partido.arbitro_1 = res[0];
           }
         );
        this.usuariosService.getDataArbitros(partido.arbitro_2).subscribe(
          res => {
            partido.arbitro_2 = res[0];
          }
        );
        this.usuariosService.getDataArbitros(partido.arbitro_3).subscribe(
          res => {

            partido.arbitro_3 = res[0];
          }
        );
        });
    },
      err => {
        console.error(err);
        swal.fire({
          title: this.texErrorPar,
          text: this.textReview,
          type: 'error',
          timer: 3000,
        });
      }
    );
  });
} else {
  this.partidos = this.partidoService.getData();
  this.usserLogged = this.usuariosService.getUserLoggedIn();
  this.usuariosService.getDataUser(this.usserLogged).subscribe(
      res => {
          this.userlog = res[0].id;
          this.permiso = res[0].PERMISO;

          if (this.permiso !== 1) {
          this.equipoService.getEquipoClub(this.userlog).subscribe(
            res => {
              this.equiposclub = res;
            }
          );
          this.categoriaService.getCategoriasClub(this.userlog).subscribe(
            res => {
              console.log(res);
              this.categorias = res;
            }
          );
          this.partidos.forEach((partido) => {
              console.log(this.partido.fecha);
              this.partidoService.getDataEquipo(partido.equipo_1).subscribe(
               res => {
                 partido.equipo_1 = res[0];
                 this.equipo1 = res[0];
                 this.clubService.getDataClub(this.equipo1.club).subscribe(
                    res => {
                    partido.club_1 = res[0].logo;
                         }, err => {
                           console.error(err);
                        }
                     );
                   }, err => {
                     console.error(err);
                   }
             );
              this.partidoService.getDataEquipo(partido.equipo_2).subscribe(
               res => {
                 partido.equipo_2 = res[0];
                 this.equipo2 = res[0];
                 this.clubService.getDataClub(this.equipo2.club).subscribe(
                    res => {
                      partido.club_2 = res[0].logo;
                         }, err => {
                           console.error(err);
                         }
                     );
                   }
               );

              this.usuariosService.getDataArbitros(partido.arbitro_1).subscribe(
                res => {
                  console.log(res[0]);
                  partido.arbitro_1 = res[0];
                }
              );
              this.usuariosService.getDataArbitros(partido.arbitro_2).subscribe(
               res => {

                 partido.arbitro_2 = res[0];
               }
             );
              this.usuariosService.getDataArbitros(partido.arbitro_3).subscribe(
               res => {

                 partido.arbitro_3 = res[0];
               }
             );
        }, err => {
          console.error(err);
          swal.fire({
            title: this.texErrorEq,
            text: this.textReview,
            type: 'error',
            timer: 3000,
          });
        }
      );
    }
    // Finalmente recuperaremos los datos a mostrar de cada partido
          this.partidos.forEach((partido) => {
        this.partidoService.getDataEquipo(partido.equipo_1).subscribe(
          res => {
            partido.equipo_1 = res[0];
            this.equipo1 = res[0];
            this.clubService.getDataClub(this.equipo1.club).subscribe(
               res => {
               partido.club_1 = res[0].logo;
                    }, err => {
                      console.error(err);
                  //    swal('¡Se ha porducido al obtener el logo del equipo local!', 'Revisa la conexión con el servidor', 'error');
                }
                );
              }, err => {
                console.error(err);
                // swal('¡Se ha porducido un error al obtener los datos del equipo local!', 'Revisa la conexión con el servidor', 'error');
              }
        );
        // console.log(partido.equipo2);
        this.partidoService.getDataEquipo(partido.equipo_2).subscribe(
          res => {
            partido.equipo_2 = res[0];
            this.equipo2 = res[0];
            this.clubService.getDataClub(this.equipo2.club).subscribe(
               res => {
                 partido.club_2 = res[0].logo;
                    }, err => {
                      console.error(err);
                    }
                );
              }
          );
        this.usuariosService.getDataArbitros(partido.arbitro_1).subscribe(
           res => {
             console.log(res[0]);
             partido.arbitro_1 = res[0];
           }
         );
        this.usuariosService.getDataArbitros(partido.arbitro_2).subscribe(
          res => {
            partido.arbitro_2 = res[0];
          }
        );
        this.usuariosService.getDataArbitros(partido.arbitro_3).subscribe(
          res => {

            partido.arbitro_3 = res[0];
          }
        );
        });
  });
  this.partidoService.removeData();
}
  }
  // Función que permitirá almacenar un partido
  savePartido() {
    this.translate.get('partidos.add_ok').subscribe(
      res => {
        this.textAddSuccess = res;
      }
    );
    this.translate.get('partidos.error_add').subscribe(
      res => {
        this.textAddError = res;
      }
    );
    this.translate.get('partidos.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );

    this.partidoService.savePartido(this.partidoI)
    .subscribe(
      res => {
        console.log(this.partidoI);
        swal.fire({
          title: this.textAddSuccess,
          type: 'success',
          timer: 2000,
        });
        this.route.navigate(['/partidos']);
      },
      err => {console.log(err);
              swal.fire({
          title: this.textAddError,
          text: this.textReview,
          type: 'error',
          timer: 2000,
        });
      }
    );
  }
  // Función que permitirá eliminar un equipo
  deletePartido(id: number) {
    this.translate.get('partidos.delete_ok').subscribe(
      res => {
        this.textSuccessDelete = res;
      }
    );
    this.translate.get('partidos.delete_error').subscribe(
      res => {
        this.textAddError = res;
      }
    );
    this.partidoService.deletePartido(id).subscribe(
      res => {
        this.ngOnInit();
        swal.fire({
          title: this.textSuccessDelete,
          type: 'success',
          timer: 2000,
        });

      },
      err => {
        console.log(err);
        swal.fire({
          title: this.textErrorDetele,
          type: 'error',
          timer: 2000,
        });
      }
    );
  }

  getPartidosEquipos() {
    this.translate.get('partidos.part_error').subscribe(
      res => {
        this.texErrorPar2 = res;
      }
    );
    this.partidoService.getPartidosEquipo(this.equipo.id).subscribe(
      res => {
        this.partidos = res;
      }, err => {
        console.error(err);
        swal.fire({
          title: this.texErrorPar2,
          type: 'warning',
          timer: 2000,
        });
      }
    );
  }

  // ----- CÓDIGO PARA EL MODAL ----

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

}
