import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { UsuariosService } from '../../services/usuarios.service';
import {AuthenticationService } from '../../services/authentication.service';
import swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email: string;
  password: string;
  log: boolean;
  token: string;

  activeLang = 'es';
  textError1: string;
  textError: string;
  constructor(private authService: AuthenticationService, private router: Router, private translate: TranslateService) {
    this.translate.setDefaultLang(this.activeLang);
   }
  @ViewChild('alert') alert: ElementRef;

  ngOnInit() {
    localStorage.removeItem('access_token');
    }

  public login() {
    this.translate.get('login.login_ko').subscribe(
      res => {
        this.textError1 = res;
      }
    );
    this.translate.get('login.login_ko2').subscribe(
      res => {
        this.textError = res;
      }
    );
    this.authService.login(this.email, this.password)
      .subscribe(
        res => {
          this.log = this.authService.isAuthenticated();
          if (this.log) {
          this.router.navigate(['/home']);

          this.token = localStorage.getItem('access_token');
          }
        },
        err => {
          console.error(err);
          swal.fire({
            title: this.textError,
            text: this.textError1,
            type: 'error',
            timer: 2000,
          });

        }
      );

  }


}
