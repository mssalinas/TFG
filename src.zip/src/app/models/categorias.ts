export interface Categoria {
  ID?: number;
  categoria?: string;
  pago_arbitros?: number;
  pago_oficiales?: number;
}
