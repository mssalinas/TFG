import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Disponibilidad } from '../models/disponibilidad';

@Injectable({
  providedIn: 'root'
})
export class DisponibilidadService {

  constructor(private http: HttpClient) { }

  API_URI = 'http://localhost:3000/api';

  getNoDisp() {
    return this.http.get(`${this.API_URI}/disp`);
  }
  saveDisp(disp: Disponibilidad) {
    return this.http.post(`${this.API_URI}/disp`, disp);
  }
  getUserDisp(id: number) {
    return this.http.get(`${this.API_URI}/disp/${id}`);
  }
  deleteDisp(id: number) {
    return this.http.delete(`${this.API_URI}/disp/${id}`);
  }
}
