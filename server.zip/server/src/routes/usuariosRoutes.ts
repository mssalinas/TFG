import {Router} from 'express';
import {usuariosController} from '../controllers/usuariosController';

class UsuariosRoutes{

    public router: Router = Router();

    constructor(){
        this.config();
    }
    config(): void{
         this.router.get ('/', usuariosController.listAll);
        this.router.get ('/:id', usuariosController.listOne);
        this.router.post ('/', usuariosController.create);
        this.router.delete ('/:id', usuariosController.delete);
        this.router.put('/:id', usuariosController.update);
        this.router.get('/user/:email', usuariosController.findUserByEmail);
    }
}

const usuariosRoutes = new UsuariosRoutes();
export default usuariosRoutes.router;