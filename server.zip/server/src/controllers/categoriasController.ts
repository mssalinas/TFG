import { Request, Response} from 'express';

import db from '../database';

class CategoriasController  {

    public async getAll (req: Request,res: Response): Promise<void> {
        const categorias = await db.query('SELECT * from categorias');
         res.json(categorias);
     }
     
     public async getDataCategoria(req: Request,res: Response){
        const { id } = req.params;
        const categoria = await db.query('SELECT * from categorias where id= ? ', [id]);
        console.log(categoria);
        if (categoria.length > 0){
            return res.json(categoria);
        }
        res.status(404).json({text: 'Categoria no encontrada'});
    } 

    public async getCategoriasClub (req: Request, res: Response){
        const equipos = await db.query('SELECT * from equipos WHERE club = ?', [req.params.id]);
        if (equipos.length > 0) {
          for (let i in equipos) {
            let categoria = equipos[i].categoria;
            const equiposcat = await db.query(
              'SELECT * FROM categorias WHERE categoria = ?  ',
              [categoria]
            );
            if (equiposcat.length > 0) {
                return res.json(equiposcat);
            }
          }
        } else {
            res.status(404).json({text: "No se han encontrado equipos"});
        }
    }

}
export const categoriasController  = new CategoriasController();