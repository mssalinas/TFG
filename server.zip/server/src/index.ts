import express, { Application } from "express";
import morgan from "morgan";
import cors from "cors";

import indexRoutes from "./routes/indexRoutes";
import usuariosRoutes from "./routes/usuariosRoutes";
import arbitrosRoutes from "./routes/arbitrosRoutes";
import oficialesRoutes from "./routes/oficialesRoutes";
import authRoutes from "./routes/authRouter";
import clubsRoutes from "./routes/clubsRoutes";
import partidosRoutes from "./routes/partidosRoutes";
import categoriasRoutes from "./routes/categoriasRoutes";
import disponibilidadRoutes from "./routes/disponibilidadRoutes";
import equiposRoutes from "./routes/equiposRoutes";
import jugadoresRoutes from "./routes/jugadoresRoutes";

import Mail from "./controllers/emailController";

const expressJwt = require("express-jwt");

class Server {
  public app: Application;

  constructor() {
    this.app = express();
    this.config();
    this.routes();
  }

  config(): void {
    this.app.set("port", process.env.PORT || 3000);
    this.app.use(morgan("dev"));
    this.app.use(cors());
    //Recibimos los datos
    // this.app.use(bodyParser.json());
    //this.app.use(bodyParser.urlencoded({extended: true}));

    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: false }));
  }

  routes(): void {
    // this.app.use(expressJwt({secret: 'todo-secret-app'}).unless({path: ['/api/login']}));
    this.app.use('/', indexRoutes);
    this.app.use('/api/usuarios', usuariosRoutes);
    this.app.use('/api/arbitros', arbitrosRoutes);
    this.app.use('/api/oficiales_mesa', oficialesRoutes);
    this.app.use('/api/login', authRoutes);
    this.app.use('/api/clubs', clubsRoutes);
    this.app.use('/api/partidos', partidosRoutes);
    this.app.use('/api/categorias', categoriasRoutes);
    this.app.use('/api/disp', disponibilidadRoutes);
    this.app.use('/api/equipos', equiposRoutes);
    this.app.use('/api/jugadores', jugadoresRoutes);
    this.app.route('/api/contactos').post((req, res) => {   
      console.log(req.body);
      Mail.to = req.body.to;
      Mail.subject = req.body.subject;
      Mail.message = req.body.message;
      let result = Mail.sendMail();
      console.log(result);
      res.json({ 'result': result })
  });
  }

  start(): void {
    this.app.listen(this.app.get("port"), () => {
      console.log("server on port");
    });
  }
}

const server = new Server();
server.start();
