import { Component, OnInit } from '@angular/core';
import { UsuariosService } from '../../../../services/usuarios.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Usuario} from '../../../../models/usuarios';
import swal from 'sweetalert2';
import { Categoria } from 'src/app/models/categorias';
import { CategoriasService } from 'src/app/services/categorias.service';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  usuarios: any = [];

  user: Usuario = {
    DNI: '',
    NOMBRE: '',
    APELLIDOS: '',
    PASSWORD: '',
    PERMISO: 2,
    CATEGORIA: 0,
    EMAIL: '',
    TELEFONO: 0,
    FECHA_NACIMIENTO: new Date(),
    IBAN: ''
  };

  edit = true;
  categorias: any = [];
  textErrorServer: string;
  textoError: string;
  textSearchError: string;
  textEditError: string;
  textEditSuccess: string;
  textSearchSuccess: string;
  textReview: string;

  constructor(private usuariosService: UsuariosService, private categoriaService: CategoriasService, private route: Router,
              private activeRoute: ActivatedRoute,  private translate: TranslateService) { }

  ngOnInit() {
    this.translate.get('arbitros.error_dat').subscribe(
      res => {
        this.textoError = res;
      }
    );
    this.translate.get('arbitros.text_error').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    // Parametros de la url
    const params = this.activeRoute.snapshot.params;
    this.categoriaService.getCategorias().subscribe(
      res => {
        this.categorias = res;
        if (params.id) {
      this.usuariosService.getArbitro(params.id)
      .subscribe(
        res => {
          console.log(res[0]);
          // Muestra los datos del usuario en el formulario
          // de edit
          this.user = res[0];
         // this.edit = true;
        },
        err => {console.error(err);
                swal.fire({
            title: this.textoError,
            text: this.textErrorServer,
            type: 'error',
            timer: 2500,
          });
        }
      );
        } else {
          this.edit = false;
        }
      });
  }
searchUser() {
  this.translate.get('arbitros_edit.no_results').subscribe(
    res => {
      this.textEditError = res;
    }
  );
  this.translate.get('arbitro.revisa').subscribe(
    res => {
      this.textReview = res;
    }
  );
  this.usuariosService.findArbitro(this.user.DNI, this.user.NOMBRE, this.user.APELLIDOS, this.user.CATEGORIA,
     this.user.EMAIL, this.user.TELEFONO, this.user.FECHA_NACIMIENTO, this.user.IBAN).subscribe(
    res => {
      this.usuarios = res;
      console.log(res);
      this.route.navigate(['/arbitros']);
      this.usuariosService.sendData(this.usuarios);
  }, err => {
      console.log(err);
      swal.fire({
      title: this.textEditError,
      text: this.textReview,
      type: 'warning',
      timer: 2500,
        });
  });
}
  updateUser() {
    this.translate.get('arbitros_edit.edit_ok').subscribe(
      res => {
        this.textEditSuccess = res;
      }
    );
    this.translate.get('arbitros_edit.edit_nook').subscribe(
      res => {
        this.textEditError = res;
      }
    );

    this.usuariosService.updateUsuario(this.user.ID, this.user)
    .subscribe(
        res => {
          swal.fire({
            title: this.textEditSuccess,
            type: 'success',
            timer: 2500,
          });
          this.route.navigate(['/arbitros/']);
        },
        err => { console.log(err);
                 swal.fire({
          title: this.textEditError,
          text: this.textReview,
          type: 'error',
          timer: 2500,
        });
      }
    );
  }
}
