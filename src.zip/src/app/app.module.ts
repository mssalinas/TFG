import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CabeceraComponent } from './components/cabecera/cabecera.component';
import { ArbitrosComponent } from './components/usuarios/arbitros/arbitros.component';
import { UsuariosListComponent } from './components/usuarios/usuarios-list/usuarios-list.component';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';

import {UsuariosService} from './services/usuarios.service';
import { LoginComponent } from './components/login/login.component';

import { JwtModule } from '@auth0/angular-jwt';
import { HomeComponent } from './components/home/home.component';
import { ClubsComponent } from './components/clubs/clubs.component';
import { PartidosComponent } from './components/partidos/partidos.component';
import { OficialesMesaComponent } from './components/usuarios/oficiales-mesa/oficiales-mesa.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { EditComponent } from './components/usuarios/arbitros/edit_arbitro/edit.component';
import { OficialesEditComponent } from './components/usuarios/oficiales-mesa/oficiales-edit/oficiales-edit.component';
import { LoginGuard } from './guards/login.guard';
import { DisponibilidadComponent } from './components/disponibilidad/disponibilidad.component';
import { DesignacionesComponent } from './components/designaciones-arbitros/designaciones.component';

import { CalendarModule, DateAdapter } from '../../node_modules/angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { DesignacionesOficialesComponent } from './components/designaciones-oficiales/designaciones-oficiales.component';
import { MisPartidosComponent } from './components/mis-partidos/mis-partidos.component';
import { ContabilidadComponent } from './components/contabilidad/contabilidad.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { EquiposComponent } from './components/equipos/equipos.component';
import { JugadoresComponent } from './components/jugadores/jugadores.component';
import { ContabilidadClubComponent } from './components/contabilidad-club/contabilidad-club.component';
import { MisDatosComponent } from './components/mis-datos/mis-datos.component';
import { MiNoDispComponent } from './components/mi-no-disp/mi-no-disp.component';
import { EditJugadorComponent } from './components/jugadores/edit/edit.component';
import { EditClubComponent } from './components/clubs/edit-club/edit-club.component';
import { EditPartidosComponent } from './components/partidos/edit/edit.component';
import { EditEquipoComponent } from './components/equipos/edit-equipo/edit-equipo.component';
import { EmailComponent } from './components/email/email.component';

@NgModule({
  declarations: [
    AppComponent,
    CabeceraComponent,
    ArbitrosComponent,
    UsuariosListComponent,
    LoginComponent,
    HomeComponent,
    ClubsComponent,
    PartidosComponent,
    OficialesMesaComponent,
    OficialesEditComponent,
    EditComponent,
    DisponibilidadComponent,
    DesignacionesComponent,
    DesignacionesOficialesComponent,
    MisPartidosComponent,
    ContabilidadComponent,
    EquiposComponent,
    JugadoresComponent,
    ContabilidadClubComponent,
    MisDatosComponent,
    MiNoDispComponent,
    EditJugadorComponent,
    EditClubComponent,
    EditPartidosComponent,
    EditEquipoComponent,
    EmailComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: function  tokenGetter() {
             return     localStorage.getItem('access_token'); },
        whitelistedDomains: ['localhost:3000'],
        blacklistedRoutes: ['http://localhost:3000/api/login']
      }
    }),
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory
    }),
    BrowserAnimationsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (http: HttpClient) => {
          return new TranslateHttpLoader(http);
        },
        deps: [ HttpClient ]
      }
    }),
  ],
  providers: [UsuariosService, LoginGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
