import { Component, OnInit, HostBinding, ViewChild, ElementRef } from '@angular/core';
import { JugadoresService } from 'src/app/services/jugadores.service';
import { ClubsService} from '../../services/clubs.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Jugadores } from '../../models/jugadores';
import swal from 'sweetalert2';
import * as jsPDF from 'jspdf';
import * as html2canvas from 'html2canvas';
import { Club } from 'src/app/models/club';
import { EquiposService } from 'src/app/services/equipos.service';
import { Equipo } from 'src/app/models/equipo';
import { UsuariosService } from 'src/app/services/usuarios.service';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { isNullOrUndefined } from 'util';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-jugadores',
  templateUrl: './jugadores.component.html',
  styleUrls: ['./jugadores.component.css']
})
export class JugadoresComponent implements OnInit {

  jugadores: any = [];
  jugadoresAux: any = [];
  jugador: Jugadores = {
    id: 0,
    club: 0,
    equipo: 0,
    DNI: '',
    nombre: '',
    apellidos: '',
    fecha_nacimiento: '',
    dorsal_juego: 0
    };
  equipo: Equipo;
  nclub: number;
  club: Club;
  usserLogged: string;
  userlog: any;
  log: any;
  dataUser: any;
  closeResult: string;

  addForm: FormGroup;
  activeLang = 'es';
  textAddSuccess: string;
  textAddError: string;
  textErrorServer: string;
  textoError: string;
  textReview: string;
  textSuccessDelete: string;
  textErrorDetele: string;

  constructor(private jugadoresService: JugadoresService, private modalService: NgbModal,
              private clubService: ClubsService, private equipoService: EquiposService, private router: Router,
              private activeRoute: ActivatedRoute, private usuariosService: UsuariosService, private form: FormBuilder,
              private translate: TranslateService) {
                this.addForm = this.form.group({
                  DNI: ['', [Validators.required, Validators.maxLength(9), Validators.minLength(9),
                    Validators.pattern('^[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKE]$')]],
                  nombre: ['', [Validators.required]],
                  apellidos: ['', [Validators.required]],
                  fecha_nacimiento: ['', [Validators.required]],
                  dorsal_juego: ['', [Validators.required]]
                });
                this.translate.setDefaultLang(this.activeLang);
              }
  @HostBinding('class') classes = 'row';
  @ViewChild('alert') alert: ElementRef;

  ngOnInit() {
    this.translate.get('jugadores.get_error').subscribe(
      res => {
        this.textoError = res;
      }
    );
    this.translate.get('arbitros.text_error').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );

    this.jugadoresAux = this.jugadoresService.getData();
    if (this.jugadoresAux.length === 0) {
    this.usserLogged = this.usuariosService.getUserLoggedIn();
    this.usuariosService.getDataUser(this.usserLogged).subscribe(
      res => {
        this.dataUser = res[0];
        if (res[0].PERMISO == null) {
          this.userlog = 4;
          console.log(this.userlog);
        } else {
        this.userlog = res[0].PERMISO;
        console.log(this.userlog);
      //  document.getElementById('buton').disabled = true;
        }
      });
    const params = this.activeRoute.snapshot.params.id;
    this.equipoService.getDataEquipo(params).subscribe(
      res => {
        this.equipo = res[0];
        this.nclub = res[0].club;
        this.jugador = {
          id: 0,
          club: this.nclub,
          equipo: params,
          DNI: '',
          nombre: '',
          apellidos: '',
          fecha_nacimiento: '',
          dorsal_juego: 0
          };
        this.clubService.getDataClub(this.nclub).subscribe(
          res => {
            this.club = res[0];
          }
        );
      }
    );
    this.jugadoresService.getJugadoresEquipo(params).subscribe(
      res => {
        this.jugadores = res;
        this.jugadores.forEach((jugador) => {
          console.log(jugador);
          });
      },
      err => {
        console.error(err);
        swal.fire({
          title: this.textoError,
          text: this.textErrorServer,
          type: 'error',
          timer: 2000,
        });
        // this.router.navigate(['/equipos', this.nclub]);
      }
    );
  } else {
    this.jugadores = this.jugadoresService.getData();
    this.jugadoresService.removeData();
  }
    }

  download() {
    document.getElementById('templatepdf').style.display = 'block';
    const data = document.getElementById('templatepdf');
    html2canvas(data).then(canvas => {
    // Few necessary setting options
    document.getElementById("templatepdf").style.display = "none";
    const imgWidth = 208;
    const pageHeight = 295;
    const imgHeight = canvas.height * imgWidth / canvas.width;
    const heightLeft = imgHeight;
    const contentDataURL = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4'); // A4 size page of PDF
    const position = 0;
    pdf.addImage(contentDataURL, 'PNG', 0, position, imgWidth, imgHeight);
    pdf.save('jugadores' + this.club.nombre + '.pdf'); // Generated PDF

  });
  }
  // Función que permitirá almacenar un equipo
  saveJugador() {
    this.translate.get('jugadores.add_ok').subscribe(
      res => {
        this.textAddSuccess = res;
      }
    );
    this.translate.get('jugadores.add_error').subscribe(
      res => {
        this.textAddError = res;
      }
    );
    this.translate.get('arbitros.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    this.jugadoresService.saveJugador(this.jugador)
    .subscribe(
      res => {
        this.router.navigate(['/clubs']);
        swal.fire({
          title: this.textAddSuccess,
          type: 'success',
          timer: 2000,
        });
      },
      err => { console.log(err);
               swal.fire({
              title: this.textAddError,
              text: this.textReview,
              type: 'error',
              timer: 2000,
            });
      }
    );
  }
  deleteJugador(id: number) {
    this.translate.get('jugadores.delok').subscribe(
      res => {
        this.textSuccessDelete = res;
      }
    );
    this.translate.get('jugadores.delerror').subscribe(
      res => {
        this.textErrorDetele = res;
      }
    );
    this.jugadoresService.deleteJugador(id).subscribe(
      res => {
        console.log(res);
        swal.fire({
          title:  this.textSuccessDelete,
          type: 'success',
          timer: 2000
        });
      }, err => {
        console.error(err);
        swal.fire({
          title: this.textErrorDetele,
          text: this.textErrorServer,
          type: 'error',
          timer: 2000});
      }
    );

  }
// -----CÓDIGO PARA MODAL ----

open(content) {
  this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    this.closeResult = `Closed with: ${result}`;
  }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  });
}
private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return  `with: ${reason}`;
  }
}
}
