import { Component, OnInit } from '@angular/core';
import {UsuariosService} from '../../services/usuarios.service';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  usserLogged: string;
  dataUser: any = [];
  club: number;

  permiso: number;

  activeLang = 'es';

  constructor(private auth: UsuariosService, private translate: TranslateService) {
    this.translate.setDefaultLang(this.activeLang);
  }

  ngOnInit() {
    this.usserLogged = this.auth.getUserLoggedIn();
    this.auth.getDataUser(this.usserLogged).subscribe(
      res => {
            this.dataUser = res[0];
            if (res[0].PERMISO == null) {
              this.permiso = 4;
              console.log(this.permiso);
            } else {
            this.permiso = res[0].PERMISO;
            console.log(this.permiso);
            }
        }
        );
      }



}
