import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MiNoDispComponent } from './mi-no-disp.component';

describe('MiNoDispComponent', () => {
  let component: MiNoDispComponent;
  let fixture: ComponentFixture<MiNoDispComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MiNoDispComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MiNoDispComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
