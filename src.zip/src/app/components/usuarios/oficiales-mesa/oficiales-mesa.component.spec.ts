import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OficialesMesaComponent } from './oficiales-mesa.component';

describe('OficialesMesaComponent', () => {
  let component: OficialesMesaComponent;
  let fixture: ComponentFixture<OficialesMesaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OficialesMesaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OficialesMesaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
