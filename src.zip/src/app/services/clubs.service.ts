import { Injectable } from '@angular/core';
import { Club } from '../models/club';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ClubsService {

constructor(private http: HttpClient) { }

API_URI = 'http://localhost:3000/api';
arrayClubes: any = [];

getClubs() {
  return this.http.get(`${this.API_URI}/clubs`);
}
getDataClub(id: number) {
  return this.http.get(`${this.API_URI}/clubs/${id}`);
}
deleteClub(id: string) {
  return this.http.delete(`${this.API_URI}/clubs/${id}`);
}
saveClub(club: Club) {
  return this.http.post(`${this.API_URI}/clubs`, club);
}
updateClub(id: number, club: Club) {
  return this.http.put(`${this.API_URI}/clubs/${id}`, club);
}
findClub(nombre: string, direccion: string, telefono: number, url_web: string, email: string, campo_juego: string, color_equipacion:string) {
  return this.http.get(`${this.API_URI}/clubs/find/?nombre=${nombre}&direccion=${direccion}&telefono=${telefono}&url_Web=${url_web}&email=${email}&campo_juego=${campo_juego}&color_equipacion=${color_equipacion}`);
}
sendData(array: any) {
  this.arrayClubes = array;
}
getData() {
  return this.arrayClubes;
}
removeData() {
  this.arrayClubes = [];
}


}
