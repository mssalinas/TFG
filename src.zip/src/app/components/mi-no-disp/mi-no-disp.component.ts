import { Component, OnInit } from '@angular/core';
import { DisponibilidadService } from 'src/app/services/disponibilidad.service';
import { UsuariosService } from 'src/app/services/usuarios.service';
import { Usuario } from 'src/app/models/usuarios';
import { Disponibilidad } from 'src/app/models/disponibilidad';
import swal from 'sweetalert2';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-mi-no-disp',
  templateUrl: './mi-no-disp.component.html',
  styleUrls: ['./mi-no-disp.component.css']
})
export class MiNoDispComponent implements OnInit {

  permiso: number;
  userlog: number;
  clublog: number;
  usserLogged: string;
  dataUser: Usuario;

  disponibilidades: any = [];
  activeLang = 'es';
  textReview: string;
  textDeleteOK: string;
  textDeleteKO: string;

  disponibilidad: Disponibilidad;

  constructor(private dispService: DisponibilidadService, private usuariosService: UsuariosService,
              private translate: TranslateService) {
                this.translate.setDefaultLang(this.activeLang);
               }

  ngOnInit() {
    this.usserLogged = this.usuariosService.getUserLoggedIn();
    this.usuariosService.getDataUser(this.usserLogged).subscribe(
        res => {
            this.dataUser = res[0];
            this.userlog = res[0].ID;
            this.permiso = res[0].PERMISO;
            this.dispService.getUserDisp(this.userlog).subscribe(
            res => {
              console.log(res);
              this.disponibilidades = res;
              this.disponibilidades.forEach(disponibilidad => {
                this.disponibilidad = disponibilidad;
              });
            }
         );
      });
  }

  deleteDispo(id: number) {
    this.translate.get('mi_no_disp.delete_ok').subscribe(
      res => {
        this.textDeleteOK = res;
      }
    );
    this.translate.get('mi_no_disp.delete_ko').subscribe(
      res => {
        this.textDeleteKO = res;
      }
    );
    this.translate.get('arbitros.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    this.dispService.deleteDisp(id).subscribe(
      res => {
        console.log(res);
        this.ngOnInit();
        swal.fire({
          title: this.textDeleteOK,
          type: 'success',
          timer: 2500,
        });
      },
      err => {
        console.log(err);
        swal.fire({
          title: this.textDeleteOK,
          text: this.textReview,
          type: 'error',
          timer: 2500,
        });
      }
    );
  }
}
