import { Request, Response } from "express";

import db from "../database";
class ArbitrosController {
  /**
	* Obtendremos el lsitado de árbitros registrados en el sistema
	*/ 
  public async listAll(req: Request, res: Response) {
    const arbitros = await db.query("SELECT * from usuarios where PERMISO = 2 ORDER BY CATEGORIA");
    res.json(arbitros);
  }
  /**
	* Se obtendrán los datos de un determinado árbitro
	*/
  public async listOneArbitro(req: Request, res: Response): Promise<any> {
    const { id } = req.params;
    const arbitro = await db.query(
      "SELECT * from usuarios where permiso = 2 and id= ? ",
      [id]
    );
    if (arbitro.length > 0) {
      return res.json(arbitro);
    }
    res.status(404).json({ text: "Árbitro no encontrado" });
  }
  /**
	* Añadir nuevo árbitro
	*/
  public async create(req: Request, res: Response): Promise<void> {
    await db.query("INSERT INTO usuarios set ?", [req.body]);
    res.json({ message: "Arbitros creado" });
  }
  public async delete(req: Request, res: Response) {
    const { id } = req.params;
    await db.query("DELETE from usuarios where id= ?", [id]);
    res.json({ message: "Árbitro eliminado correctamente" });
  }
  public async update(req: Request, res: Response) {
    const { id } = req.params;
    await db.query("UPDATE usuarios set ? WHERE id = ?", [req.body, id]);
    res.json({ message: "Árbitro actualizado correctamente" });
  }
  public async find(req: Request, res: Response) {
    const user = await db.query('SELECT * FROM usuarios WHERE PERMISO = 2 AND (DNI LIKE ? and NOMBRE LIKE ? and APELLIDOS LIKE ? or CATEGORIA = ? AND EMAIL LIKE ? AND TELEFONO LIKE ? AND FECHA_NACIMIENTO LIKE ? AND IBAN LIKE ?) ', 
    ['%'+req.query.DNI +'%', '%'+req.query.NOMBRE+'%', '%'+req.query.APELLIDOS+'%', req.query.CATEGORIA, '%'+req.query.EMAIL+'%', '%'+req.query.TELEFONO+'%', '%'+req.query.FECHA_NACIMIENTO+'%', '%'+req.query.IBAN+'%']);
    if (user.length > 0){
      res.json(user);
    }else{
      res.status(404).json({text: "No se han encontrado resultados de búsqueda"});
    }
  }
  public async findUserByEmail(req: Request, res: Response) {
    await db.query("SELECT * FROM usuarios WHERE email = ?", [req.body.email]);
    res.json({ message: "User exists" });
  }
  public async findArbitroByCategory(req: Request, res: Response) {
    const { id } = req.params;
    const partido = await db.query(
      "SELECT fecha, hora FROM partidos WHERE id = ?",
      [req.query.partido]
    );
    let fecha = partido[0].fecha;
    let hora = partido[0].hora;
    if (partido.length > 0) {
      const users = await db.query(
        "SELECT * FROM usuarios WHERE CATEGORIA = ? and PERMISO = 2",
        [id]
      );
      for (let i in users) {
        let user = users[i].ID;
        const partidos = await db.query("SELECT * from partidos WHERE hora = ? AND arbitro_1 = ? or arbitro_2 = ? or arbitro_3 = ?", [hora, user, user, user]);
        if (partidos.length > 0){
          users.splice(users[i], 1);
        }
        console.log(users);
        const disp = await db.query(
          "SELECT * FROM disponibilidad WHERE usuario = ? ",
          [user]
        );
        if (disp.length > 0) {
          await db.query(
            "SELECT * from disponibilidad WHERE fecha_no_disp = ? and usuario = ?",
            [fecha, user]
          );
          users.splice(users[i], 1);
        }
      }
      return res.json(users);
    }
    res.status(404).json({ text: "Categoria no encontrada" });
  }
}
export const arbitrosController = new ArbitrosController();
