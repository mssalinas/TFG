import { Time } from '@angular/common';

export interface Equipo {
  id?: number;
  club?: number;
  nombre?: string;
  categoria?: number;
  num_jugadores?: number;
}
