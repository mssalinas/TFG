import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Club } from 'src/app/models/club';
import swal from 'sweetalert2';
import { ClubsService } from '../../../services/clubs.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-edit-club',
  templateUrl: './edit-club.component.html',
  styleUrls: ['./edit-club.component.css']
})
export class EditClubComponent implements OnInit {
  selectedFile: File;
  imageSrc: string | ArrayBuffer;

  clubes: any = [];

  club: Club = {
    nombre: '',
    password: '',
    direccion: '',
    telefono: 0,
    url_web: '',
    email: '',
    campo_juego: '',
    color_equipacion: '',
    logo: '',
  };
  edit = true;

  textErrorServer: string;
  textoError: string;
  textSearchError: string;
  textEditError: string;
  textEditSuccess: string;
  textSearchSuccess: string;
  textReview: string;
  activeLang = 'es';
  textExt: string;
  textSelec: string;


  constructor(private route: Router, private clubService: ClubsService, private activeRoute: ActivatedRoute,
              private translate: TranslateService) {
          this.translate.setDefaultLang(this.activeLang);
               }

  ngOnInit() {
    this.translate.get('edit_club.get_error').subscribe(
      res => {
        this.textoError = res;
      }
    );
    this.translate.get('club.conexion').subscribe(
      res => {
        this.textErrorServer = res;
      }
    );
    // Parametros de la url
    const params = this.activeRoute.snapshot.params;
    if (params.id) {
      this.clubService.getDataClub(params.id)
      .subscribe(
        res => {
          console.log(res);
          // Muestra los datos del usuario en el formulario
          // de edit
          this.club = res[0];
         // this.edit = true;
          console.log(res[0]);
        },
        err => {console.error(err);
                swal.fire({
            title: this.textoError,
            text: this.textErrorServer,
            type: 'error',
            timer: 2500,
          });
        }
      );
        } else {
          this.edit = false;
        }
  }
  fileSelected(event) {
    this.translate.get('mis_partidos.extension').subscribe(
      res => {
        this.textExt = res;
      }
    );
    this.translate.get('mis_partidos.selec').subscribe(
      res => {
        this.textSelec = res;
      }
    );
    this.selectedFile = event.target.files[0];
    if (event.target.files && event.target.files[0]) {
          const file = event.target.files[0];

          const reader = new FileReader();
          reader.onload = e => this.imageSrc = reader.result;

          reader.readAsDataURL(file);
       }
    const extensiones = ['jpg', 'jpeg', 'png', 'JPG', 'JPEG', 'JFIF', 'BMP', 'SVG'];
    const extensionArchivo = this.selectedFile.name.split('.').pop();
    if (!extensiones.includes(extensionArchivo)) {
      document.getElementById('btns').style.display = 'none';
      swal.fire({
        title: this.textExt,
        text: this.textSelec,
        type: 'error',
        timer: 2000,
      });
     } else {
       document.getElementById('btns').style.display = 'block';
     }
    }
  updateClub() {
    this.translate.get('edit_club.edit_ko').subscribe(
      res => {
        this.textEditError = res;
      }
    );
    this.translate.get('edit_club.edit_ok').subscribe(
      res => {
        this.textEditSuccess = res;
      }
    );
    this.translate.get('club.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    // Si no quiero que modifique un dato delete this.user.dato
    const fd = new FormData();
    // console.log(this.selectedFile.name);
    // fd.append('image', this.selectedFile, this.selectedFile.name);
    const id = this.activeRoute.snapshot.params.id;
    console.log(id);
    console.log(this.club);
    this.clubService.updateClub(id, this.club)
    .subscribe(
        res => {
          this.route.navigate(['/clubs/']);
          swal.fire({
            title: this.textEditSuccess,
            type: 'success',
            timer: 2000,
          });
        },
        err => { console.log(err);
                 swal.fire({
          title: this.textEditError,
          text: this.textReview,
          type: 'error',
          timer: 2500,
        });
      }
    );
  }

  searchClub() {
    this.translate.get('jugadores_edit.search_ko').subscribe(
      res => {
        this.textSearchError = res;
      }
    );
    this.translate.get('club.revisa').subscribe(
      res => {
        this.textReview = res;
      }
    );
    this.edit = false;
    this.clubService.findClub(this.club.nombre, this.club.direccion, this.club.telefono, this.club.url_web,
      this.club.email, this.club.campo_juego, this.club.color_equipacion).subscribe(
      res => {
          console.log(res);
          this.clubes = res;
          this.route.navigate(['/clubs']);
          this.clubService.sendData(this.clubes);
      },
      err => {
        console.log(err);
        swal.fire({
        title: this.textSearchError,
        text: this.textReview,
        type: 'warning',
        timer: 2500,
          });
      }
    );
  }

}
